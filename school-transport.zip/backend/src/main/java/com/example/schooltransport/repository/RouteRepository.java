package com.example.schooltransport.repository;
import com.example.schooltransport.model.Route;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface RouteRepository extends MongoRepository<Route, String> {}
