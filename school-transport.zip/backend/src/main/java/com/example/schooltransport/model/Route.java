package com.example.schooltransport.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "routes")
public class Route {
    @Id private String id;
    private String routeId;
    private String routeName;
    private String busNumber;
    private double seatsAvailable;
    private String driver;
    public Route() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getRouteId() { return routeId; }
    public void setRouteId(String routeId) { this.routeId = routeId; }
    public String getRouteName() { return routeName; }
    public void setRouteName(String routeName) { this.routeName = routeName; }
    public String getBusNumber() { return busNumber; }
    public void setBusNumber(String busNumber) { this.busNumber = busNumber; }
    public double getSeatsAvailable() { return seatsAvailable; }
    public void setSeatsAvailable(double seatsAvailable) { this.seatsAvailable = seatsAvailable; }
    public String getDriver() { return driver; }
    public void setDriver(String driver) { this.driver = driver; }
}
