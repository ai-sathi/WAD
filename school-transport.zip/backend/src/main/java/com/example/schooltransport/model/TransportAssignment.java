package com.example.schooltransport.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "transportAssignments")
public class TransportAssignment {
    @Id private String id;
    private String assignmentId;
    private String routeId;
    private String studentName;
    private String pickupPoint;
    private String status;
    public TransportAssignment() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getAssignmentId() { return assignmentId; }
    public void setAssignmentId(String assignmentId) { this.assignmentId = assignmentId; }
    public String getRouteId() { return routeId; }
    public void setRouteId(String routeId) { this.routeId = routeId; }
    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }
    public String getPickupPoint() { return pickupPoint; }
    public void setPickupPoint(String pickupPoint) { this.pickupPoint = pickupPoint; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
