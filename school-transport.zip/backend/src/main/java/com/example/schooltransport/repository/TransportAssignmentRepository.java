package com.example.schooltransport.repository;
import com.example.schooltransport.model.TransportAssignment;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface TransportAssignmentRepository extends MongoRepository<TransportAssignment, String> {}
