export default {
  "title": "School Transport Management",
  "collections": [
    "routes",
    "transportAssignments"
  ],
  "fields": {
    "routes": [
      {
        "key": "routeId",
        "label": "Route ID",
        "type": "text"
      },
      {
        "key": "routeName",
        "label": "Route name",
        "type": "text"
      },
      {
        "key": "busNumber",
        "label": "Bus number",
        "type": "text"
      },
      {
        "key": "seatsAvailable",
        "label": "Seats available",
        "type": "number"
      },
      {
        "key": "driver",
        "label": "Driver",
        "type": "text"
      }
    ],
    "transportAssignments": [
      {
        "key": "assignmentId",
        "label": "Assignment ID",
        "type": "text"
      },
      {
        "key": "routeId",
        "label": "Route ID",
        "type": "text"
      },
      {
        "key": "studentName",
        "label": "Student name",
        "type": "text"
      },
      {
        "key": "pickupPoint",
        "label": "Pickup point",
        "type": "text"
      },
      {
        "key": "status",
        "label": "Status",
        "type": "text"
      }
    ]
  },
  "specialTitle": "Routes with seats available",
  "specialDescription": "routes with seatsAvailable > 0",
  "relation": "routeId"
}