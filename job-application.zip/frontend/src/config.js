export default {
  "title": "Job Application Management",
  "collections": [
    "jobs",
    "applications"
  ],
  "fields": {
    "jobs": [
      {
        "key": "jobId",
        "label": "Job ID",
        "type": "text"
      },
      {
        "key": "title",
        "label": "Job title",
        "type": "text"
      },
      {
        "key": "department",
        "label": "Department",
        "type": "text"
      },
      {
        "key": "openings",
        "label": "Openings",
        "type": "number"
      },
      {
        "key": "location",
        "label": "Location",
        "type": "text"
      }
    ],
    "applications": [
      {
        "key": "applicationId",
        "label": "Application ID",
        "type": "text"
      },
      {
        "key": "jobId",
        "label": "Job ID",
        "type": "text"
      },
      {
        "key": "applicantName",
        "label": "Applicant name",
        "type": "text"
      },
      {
        "key": "appliedDate",
        "label": "Applied date",
        "type": "date"
      },
      {
        "key": "status",
        "label": "Status",
        "type": "text"
      }
    ]
  },
  "specialTitle": "Open jobs",
  "specialDescription": "jobs with openings > 0",
  "relation": "jobId"
}