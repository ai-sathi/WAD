package com.example.jobapplication.repository;
import com.example.jobapplication.model.Application;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ApplicationRepository extends MongoRepository<Application, String> {}
