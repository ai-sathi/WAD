package com.example.jobapplication.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "jobs")
public class Job {
    @Id private String id;
    private String jobId;
    private String title;
    private String department;
    private double openings;
    private String location;
    public Job() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getJobId() { return jobId; }
    public void setJobId(String jobId) { this.jobId = jobId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public double getOpenings() { return openings; }
    public void setOpenings(double openings) { this.openings = openings; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
}
