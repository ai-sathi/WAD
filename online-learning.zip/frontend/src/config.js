export default {
  "title": "Online Learning Management",
  "collections": [
    "courses",
    "enrollments"
  ],
  "fields": {
    "courses": [
      {
        "key": "courseId",
        "label": "Course ID",
        "type": "text"
      },
      {
        "key": "title",
        "label": "Course title",
        "type": "text"
      },
      {
        "key": "instructor",
        "label": "Instructor",
        "type": "text"
      },
      {
        "key": "durationWeeks",
        "label": "Duration (weeks)",
        "type": "number"
      },
      {
        "key": "active",
        "label": "Active (true/false)",
        "type": "text"
      }
    ],
    "enrollments": [
      {
        "key": "enrollmentId",
        "label": "Enrollment ID",
        "type": "text"
      },
      {
        "key": "courseId",
        "label": "Course ID",
        "type": "text"
      },
      {
        "key": "studentName",
        "label": "Student name",
        "type": "text"
      },
      {
        "key": "enrolledDate",
        "label": "Enrollment date",
        "type": "date"
      },
      {
        "key": "status",
        "label": "Status",
        "type": "text"
      }
    ]
  },
  "specialTitle": "Active enrollments",
  "specialDescription": "enrollments with status=Active",
  "relation": "courseId"
}