package com.example.onlinelearning.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "enrollments")
public class Enrollment {
    @Id private String id;
    private String enrollmentId;
    private String courseId;
    private String studentName;
    private String enrolledDate;
    private String status;
    public Enrollment() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getEnrollmentId() { return enrollmentId; }
    public void setEnrollmentId(String enrollmentId) { this.enrollmentId = enrollmentId; }
    public String getCourseId() { return courseId; }
    public void setCourseId(String courseId) { this.courseId = courseId; }
    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }
    public String getEnrolledDate() { return enrolledDate; }
    public void setEnrolledDate(String enrolledDate) { this.enrolledDate = enrolledDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
