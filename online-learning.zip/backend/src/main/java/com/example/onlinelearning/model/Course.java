package com.example.onlinelearning.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "courses")
public class Course {
    @Id private String id;
    private String courseId;
    private String title;
    private String instructor;
    private double durationWeeks;
    private String active;
    public Course() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getCourseId() { return courseId; }
    public void setCourseId(String courseId) { this.courseId = courseId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getInstructor() { return instructor; }
    public void setInstructor(String instructor) { this.instructor = instructor; }
    public double getDurationWeeks() { return durationWeeks; }
    public void setDurationWeeks(double durationWeeks) { this.durationWeeks = durationWeeks; }
    public String getActive() { return active; }
    public void setActive(String active) { this.active = active; }
}
