package com.example.lab.controller;

import com.example.lab.model.Appointment;
import com.example.lab.service.LabService;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/appointments")
@CrossOrigin(origins = "http://localhost:5173")
public class LabController {
    private final LabService service;
    public LabController(LabService service) { this.service = service; }

    @GetMapping
    public List<Appointment> all() { return service.all(); }

    @GetMapping("/{id}")
    public ResponseEntity<Appointment> get(@PathVariable String id) {
        return service.find(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Appointment> update(@PathVariable String id, @RequestBody Appointment body) {
        Appointment updated = service.update(id, body);
        return updated == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(updated);
    }

    @GetMapping("/joined")
    public List<Map> joined() { return service.joined(); }
}
