package com.example.lab.service;

import com.example.lab.model.Appointment;
import com.example.lab.repository.AppointmentRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final AppointmentRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(AppointmentRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<Appointment> find(String id) { return repository.findById(id); }
    public Appointment update(String id, Appointment incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("doctors", "doctorId", "doctorId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "appointments", Map.class).getMappedResults();
    }
    public List<Appointment> all() { return repository.findAll(); }
}
