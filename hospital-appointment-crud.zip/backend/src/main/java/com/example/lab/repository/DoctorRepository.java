package com.example.lab.repository;
import com.example.lab.model.Doctor;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface DoctorRepository extends MongoRepository<Doctor, String> {}
