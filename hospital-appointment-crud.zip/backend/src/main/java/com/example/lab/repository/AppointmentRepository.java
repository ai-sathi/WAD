package com.example.lab.repository;
import com.example.lab.model.Appointment;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface AppointmentRepository extends MongoRepository<Appointment, String> {}
