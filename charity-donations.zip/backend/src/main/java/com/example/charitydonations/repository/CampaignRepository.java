package com.example.charitydonations.repository;
import com.example.charitydonations.model.Campaign;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface CampaignRepository extends MongoRepository<Campaign, String> {}
