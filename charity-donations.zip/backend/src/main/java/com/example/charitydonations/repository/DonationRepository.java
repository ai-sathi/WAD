package com.example.charitydonations.repository;
import com.example.charitydonations.model.Donation;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface DonationRepository extends MongoRepository<Donation, String> {}
