export default {
  "title": "Charity Donation Management",
  "collections": [
    "campaigns",
    "donations"
  ],
  "fields": {
    "campaigns": [
      {
        "key": "campaignId",
        "label": "Campaign ID",
        "type": "text"
      },
      {
        "key": "name",
        "label": "Campaign name",
        "type": "text"
      },
      {
        "key": "cause",
        "label": "Cause",
        "type": "text"
      },
      {
        "key": "targetAmount",
        "label": "Target amount",
        "type": "number"
      },
      {
        "key": "endDate",
        "label": "End date",
        "type": "date"
      }
    ],
    "donations": [
      {
        "key": "donationId",
        "label": "Donation ID",
        "type": "text"
      },
      {
        "key": "campaignId",
        "label": "Campaign ID",
        "type": "text"
      },
      {
        "key": "donorName",
        "label": "Donor name",
        "type": "text"
      },
      {
        "key": "amount",
        "label": "Amount",
        "type": "number"
      },
      {
        "key": "date",
        "label": "Date",
        "type": "date"
      }
    ]
  },
  "specialTitle": "Fundraising campaigns",
  "specialDescription": "campaigns with targetAmount > 0",
  "relation": "campaignId"
}