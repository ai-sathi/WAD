package com.example.lab.service;

import com.example.lab.model.Reservation;
import com.example.lab.repository.ReservationRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final ReservationRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(ReservationRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<Reservation> find(String id) { return repository.findById(id); }
    public Reservation update(String id, Reservation incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("rooms", "roomId", "roomId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "reservations", Map.class).getMappedResults();
    }
    public List<Reservation> all() { return repository.findAll(); }
}
