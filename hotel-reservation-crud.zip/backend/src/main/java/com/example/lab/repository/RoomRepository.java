package com.example.lab.repository;
import com.example.lab.model.Room;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface RoomRepository extends MongoRepository<Room, String> {}
