package com.example.lab.repository;
import com.example.lab.model.Reservation;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ReservationRepository extends MongoRepository<Reservation, String> {}
