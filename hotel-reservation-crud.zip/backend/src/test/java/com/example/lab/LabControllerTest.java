package com.example.lab;

import com.example.lab.model.Reservation;
import com.example.lab.service.LabService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.util.Optional;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = com.example.lab.controller.LabController.class)
class LabControllerTest {
 @Autowired MockMvc mvc;
 @Autowired ObjectMapper mapper;
 @MockBean LabService service;

 @Test void getMissingRecordReturns404() throws Exception {
   when(service.find("missing")).thenReturn(Optional.empty());
   mvc.perform(get("/api/reservations/missing"))
      .andExpect(status().isNotFound());
 }

 @Test void listEndpointReturns200() throws Exception {
   when(service.all()).thenReturn(java.util.Collections.emptyList());
   mvc.perform(get("/api/reservations"))
      .andExpect(status().isOk());
 }
}
