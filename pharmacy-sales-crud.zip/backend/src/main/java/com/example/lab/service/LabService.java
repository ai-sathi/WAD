package com.example.lab.service;

import com.example.lab.model.Sale;
import com.example.lab.repository.SaleRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final SaleRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(SaleRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<Sale> find(String id) { return repository.findById(id); }
    public Sale update(String id, Sale incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("medicines", "medicineId", "medicineId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "sales", Map.class).getMappedResults();
    }
    public List<Sale> all() { return repository.findAll(); }
}
