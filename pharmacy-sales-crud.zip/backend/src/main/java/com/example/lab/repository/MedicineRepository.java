package com.example.lab.repository;
import com.example.lab.model.Medicine;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface MedicineRepository extends MongoRepository<Medicine, String> {}
