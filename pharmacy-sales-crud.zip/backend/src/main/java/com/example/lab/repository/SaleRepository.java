package com.example.lab.repository;
import com.example.lab.model.Sale;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface SaleRepository extends MongoRepository<Sale, String> {}
