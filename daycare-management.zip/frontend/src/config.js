export default {
  "title": "Daycare Management",
  "collections": [
    "children",
    "attendance"
  ],
  "fields": {
    "children": [
      {
        "key": "childId",
        "label": "Child ID",
        "type": "text"
      },
      {
        "key": "name",
        "label": "Child name",
        "type": "text"
      },
      {
        "key": "age",
        "label": "Age",
        "type": "number"
      },
      {
        "key": "guardian",
        "label": "Guardian",
        "type": "text"
      },
      {
        "key": "active",
        "label": "Active (true/false)",
        "type": "text"
      }
    ],
    "attendance": [
      {
        "key": "attendanceId",
        "label": "Attendance ID",
        "type": "text"
      },
      {
        "key": "childId",
        "label": "Child ID",
        "type": "text"
      },
      {
        "key": "date",
        "label": "Date",
        "type": "date"
      },
      {
        "key": "checkIn",
        "label": "Check-in time",
        "type": "text"
      },
      {
        "key": "status",
        "label": "Status",
        "type": "text"
      }
    ]
  },
  "specialTitle": "Today attendance",
  "specialDescription": "attendance records for today",
  "relation": "childId"
}