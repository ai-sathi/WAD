package com.example.daycaremanagement.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "children")
public class Child {
    @Id private String id;
    private String childId;
    private String name;
    private double age;
    private String guardian;
    private String active;
    public Child() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getChildId() { return childId; }
    public void setChildId(String childId) { this.childId = childId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public double getAge() { return age; }
    public void setAge(double age) { this.age = age; }
    public String getGuardian() { return guardian; }
    public void setGuardian(String guardian) { this.guardian = guardian; }
    public String getActive() { return active; }
    public void setActive(String active) { this.active = active; }
}
