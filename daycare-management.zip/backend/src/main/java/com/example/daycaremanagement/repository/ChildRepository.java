package com.example.daycaremanagement.repository;
import com.example.daycaremanagement.model.Child;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ChildRepository extends MongoRepository<Child, String> {}
