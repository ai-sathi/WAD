package com.example.daycaremanagement.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "attendance")
public class Attendance {
    @Id private String id;
    private String attendanceId;
    private String childId;
    private String date;
    private String checkIn;
    private String status;
    public Attendance() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getAttendanceId() { return attendanceId; }
    public void setAttendanceId(String attendanceId) { this.attendanceId = attendanceId; }
    public String getChildId() { return childId; }
    public void setChildId(String childId) { this.childId = childId; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    public String getCheckIn() { return checkIn; }
    public void setCheckIn(String checkIn) { this.checkIn = checkIn; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
