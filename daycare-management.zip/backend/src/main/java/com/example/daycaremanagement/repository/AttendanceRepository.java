package com.example.daycaremanagement.repository;
import com.example.daycaremanagement.model.Attendance;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface AttendanceRepository extends MongoRepository<Attendance, String> {}
