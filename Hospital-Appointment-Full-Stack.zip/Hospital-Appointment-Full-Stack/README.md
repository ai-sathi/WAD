# Hospital Appointment Management — exam practice

This project follows the simple Options API style of the uploaded Vue CRUD template and keeps the Spring Boot Java classes in one package (`com.example.demo`) so the code is easy to follow.

## Collections
- `doctors`: `id`, `doctorId`, `name`, `specialization`, `availableDays`
- `appointments`: `id`, `appointmentId`, `patientName`, `doctorId`, `appointmentDate`, `status`

The relationship is `appointments.doctorId` → `doctors.doctorId`.

## Requirements covered
- Create, read, update and delete doctors.
- Create, read, update and delete appointments.
- Find a record by its MongoDB ID and load it into the edit form.
- Show pending appointments.
- Aggregation endpoint `/appointments/with-doctors` uses `$lookup` to return appointment records with matching doctor details.
- Vue uses Axios and normal input fields, selects, and tables; there is no JSON editor.

## Run backend
1. Start MongoDB locally on port `27017`.
2. Open the `backend` folder in IntelliJ or a terminal.
3. Run:
   ```powershell
   mvn spring-boot:run
   ```
4. Backend runs at `http://localhost:8080`.

## Run frontend
Open a second terminal:
```powershell
cd frontend
npm install
npm run dev
```
Open the URL Vite prints, normally `http://localhost:5173`.

## Useful endpoints
- `GET/POST /doctors`
- `GET/PUT/DELETE /doctors/{mongoId}`
- `GET/POST /appointments`
- `GET/PUT/DELETE /appointments/{mongoId}`
- `GET /appointments/by-code/{appointmentId}`
- `GET /appointments/pending`
- `GET /appointments/with-doctors`

Note: `/appointments/{mongoId}` uses MongoDB's generated `_id`, while `appointmentId` is the human-readable code such as `A101`. To test the join, create a doctor first, then create an appointment with the same `doctorId`.
