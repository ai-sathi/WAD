package com.example.demo;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface DoctorRepository extends MongoRepository<Doctor, String> {
    Doctor findByDoctorId(String doctorId);
}
