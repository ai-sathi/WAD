package com.example.demo;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AppointmentRepository extends MongoRepository<Appointment, String> {
    Appointment findByAppointmentId(String appointmentId);
    List<Appointment> findByStatusIgnoreCase(String status);
}
