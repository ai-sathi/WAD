package com.example.demo;

import java.util.List;
import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.LookupOperation;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/appointments")
@CrossOrigin(origins = "http://localhost:5173")
public class AppointmentController {
    private final AppointmentRepository repo;
    private final MongoTemplate mongoTemplate;

    public AppointmentController(AppointmentRepository repo, MongoTemplate mongoTemplate) {
        this.repo = repo;
        this.mongoTemplate = mongoTemplate;
    }

    @PostMapping
    public Appointment addAppointment(@RequestBody Appointment appointment) {
        appointment.setId(null);
        return repo.save(appointment);
    }

    @GetMapping
    public List<Appointment> getAppointments() {
        return repo.findAll();
    }

    // Find by MongoDB document ID.
    @GetMapping("/{id}")
    public ResponseEntity<Appointment> getAppointment(@PathVariable String id) {
        return repo.findById(id).map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Find by the user-facing appointment ID.
    @GetMapping("/by-code/{appointmentId}")
    public ResponseEntity<Appointment> getByAppointmentId(@PathVariable String appointmentId) {
        Appointment appointment = repo.findByAppointmentId(appointmentId);
        return appointment == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(appointment);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Appointment> updateAppointment(
            @PathVariable String id, @RequestBody Appointment appointment) {
        if (!repo.existsById(id)) return ResponseEntity.notFound().build();
        appointment.setId(id);
        return ResponseEntity.ok(repo.save(appointment));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAppointment(@PathVariable String id) {
        if (!repo.existsById(id)) return ResponseEntity.notFound().build();
        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    // Question-specific operation: display appointments that are still pending.
    @GetMapping("/pending")
    public List<Appointment> getPendingAppointments() {
        return repo.findByStatusIgnoreCase("Pending");
    }

    // Aggregation: combine appointments with the matching doctor.
    @GetMapping("/with-doctors")
    public List<Document> getAppointmentsWithDoctors() {
        LookupOperation lookup = lookup("doctors", "doctorId", "doctorId", "doctorDetails");
        Aggregation aggregation = newAggregation(lookup);
        AggregationResults<Document> results =
                mongoTemplate.aggregate(aggregation, "appointments", Document.class);
        return results.getMappedResults();
    }
}
