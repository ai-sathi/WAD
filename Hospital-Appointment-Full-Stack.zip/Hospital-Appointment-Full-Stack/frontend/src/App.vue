<template>
  <div class="page">
    <h1>Hospital Appointment Management</h1>
    <p class="intro">Manage doctors and patient appointments.</p>

    <section class="card">
      <h2>Choose records</h2>
      <button :class="{ active: section === 'appointments' }" @click="chooseSection('appointments')">Appointments</button>
      <button :class="{ active: section === 'doctors' }" @click="chooseSection('doctors')">Doctors</button>
      <button class="secondary" @click="loadPending">Show Pending Appointments</button>
      <button class="secondary" @click="loadJoined">Show Appointments with Doctor Details</button>
      <button class="secondary" @click="loadAll">Show All</button>
    </section>

    <section class="card">
      <h2>{{ editingId ? 'Edit' : 'Add' }} {{ section === 'doctors' ? 'Doctor' : 'Appointment' }}</h2>

      <form v-if="section === 'doctors'" @submit.prevent="saveDoctor">
        <input v-model="doctorForm.doctorId" placeholder="Doctor code (e.g. D101)" required>
        <input v-model="doctorForm.name" placeholder="Doctor name" required>
        <input v-model="doctorForm.specialization" placeholder="Specialization" required>
        <input v-model="doctorForm.availableDays" placeholder="Available days (e.g. Mon, Wed)" required>
        <div>
          <button type="submit">{{ editingId ? 'Update Doctor' : 'Add Doctor' }}</button>
          <button type="button" class="secondary" @click="resetForm">Clear</button>
        </div>
      </form>

      <form v-else @submit.prevent="saveAppointment">
        <input v-model="appointmentForm.appointmentId" placeholder="Appointment code (e.g. A101)" required>
        <input v-model="appointmentForm.patientName" placeholder="Patient name" required>
        <select v-model="appointmentForm.doctorId" required>
          <option disabled value="">Choose doctor</option>
          <option v-for="d in doctors" :key="d.id" :value="d.doctorId">
            {{ d.doctorId }} — {{ d.name }} ({{ d.specialization }})
          </option>
        </select>
        <label>Appointment date</label>
        <input v-model="appointmentForm.appointmentDate" type="date" required>
        <select v-model="appointmentForm.status" required>
          <option>Pending</option>
          <option>Confirmed</option>
          <option>Completed</option>
          <option>Cancelled</option>
        </select>
        <div>
          <button type="submit">{{ editingId ? 'Update Appointment' : 'Add Appointment' }}</button>
          <button type="button" class="secondary" @click="resetForm">Clear</button>
        </div>
      </form>
      <p class="message">{{ message }}</p>
    </section>

    <section class="card">
      <h2>Find by MongoDB ID</h2>
      <div class="inline">
        <input v-model="findId" placeholder="Paste record ID from the table">
        <button @click="findById">Find</button>
      </div>
      <p class="hint">Use the ID shown in the first column. The selected record will load into the form for editing.</p>
    </section>

    <section class="card">
      <h2>{{ tableTitle }}</h2>
      <div class="inline">
        <input v-model="searchText" placeholder="Search visible rows">
        <button class="secondary" @click="loadAll">Refresh</button>
      </div>

      <div class="table-wrap" v-if="section === 'doctors' && !joinedMode">
        <table>
          <thead><tr><th>MongoDB ID</th><th>Doctor Code</th><th>Name</th><th>Specialization</th><th>Available Days</th><th>Actions</th></tr></thead>
          <tbody>
            <tr v-for="d in filteredDoctors" :key="d.id">
              <td class="id">{{ d.id }}</td><td>{{ d.doctorId }}</td><td>{{ d.name }}</td><td>{{ d.specialization }}</td><td>{{ d.availableDays }}</td>
              <td><button @click="editDoctor(d)">Edit</button><button class="danger" @click="deleteRecord('doctors', d.id)">Delete</button></td>
            </tr>
          </tbody>
        </table>
        <p v-if="filteredDoctors.length === 0">No doctors found.</p>
      </div>

      <div class="table-wrap" v-else-if="!joinedMode">
        <table>
          <thead><tr><th>MongoDB ID</th><th>Appointment Code</th><th>Patient</th><th>Doctor Code</th><th>Date</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            <tr v-for="a in filteredAppointments" :key="a.id">
              <td class="id">{{ a.id }}</td><td>{{ a.appointmentId }}</td><td>{{ a.patientName }}</td><td>{{ a.doctorId }}</td><td>{{ a.appointmentDate }}</td><td>{{ a.status }}</td>
              <td><button @click="editAppointment(a)">Edit</button><button class="danger" @click="deleteRecord('appointments', a.id)">Delete</button></td>
            </tr>
          </tbody>
        </table>
        <p v-if="filteredAppointments.length === 0">No appointments found.</p>
      </div>

      <div class="table-wrap" v-else>
        <table>
          <thead><tr><th>Appointment Code</th><th>Patient</th><th>Date</th><th>Status</th><th>Doctor Details</th></tr></thead>
          <tbody>
            <tr v-for="a in joinedAppointments" :key="a._id">
              <td>{{ a.appointmentId }}</td><td>{{ a.patientName }}</td><td>{{ a.appointmentDate }}</td><td>{{ a.status }}</td>
              <td>
                <span v-if="a.doctorDetails && a.doctorDetails.length">
                  {{ a.doctorDetails[0].name }} — {{ a.doctorDetails[0].specialization }}
                </span>
                <span v-else>Doctor not found</span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  </div>
</template>

<script>
import axios from 'axios'

const API = 'http://localhost:8080'

export default {
  data() {
    return {
      section: 'appointments',
      doctors: [],
      appointments: [],
      joinedAppointments: [],
      joinedMode: false,
      editingId: null,
      findId: '',
      searchText: '',
      message: '',
      doctorForm: { doctorId: '', name: '', specialization: '', availableDays: '' },
      appointmentForm: { appointmentId: '', patientName: '', doctorId: '', appointmentDate: '', status: 'Pending' }
    }
  },

  computed: {
    tableTitle() {
      if (this.joinedMode) return 'Appointments with Doctor Details'
      return this.section === 'doctors' ? 'Doctor Records' : 'Appointment Records'
    },
    filteredDoctors() {
      const q = this.searchText.toLowerCase()
      return this.doctors.filter(d =>
        [d.doctorId, d.name, d.specialization, d.availableDays].some(v => String(v || '').toLowerCase().includes(q))
      )
    },
    filteredAppointments() {
      const q = this.searchText.toLowerCase()
      return this.appointments.filter(a =>
        [a.appointmentId, a.patientName, a.doctorId, a.appointmentDate, a.status].some(v => String(v || '').toLowerCase().includes(q))
      )
    }
  },

  methods: {
    async chooseSection(section) {
      this.section = section
      this.joinedMode = false
      this.resetForm()
      await this.loadAll()
    },

    async loadAll() {
      this.joinedMode = false
      this.message = ''
      try {
        const [doctorRes, appointmentRes] = await Promise.all([
          axios.get(`${API}/doctors`),
          axios.get(`${API}/appointments`)
        ])
        this.doctors = doctorRes.data
        this.appointments = appointmentRes.data
      } catch (e) {
        this.message = 'Could not load records. Check that backend and MongoDB are running.'
      }
    },

    async loadPending() {
      this.section = 'appointments'
      this.joinedMode = false
      try {
        const res = await axios.get(`${API}/appointments/pending`)
        this.appointments = res.data
        this.message = 'Showing pending appointments.'
      } catch (e) {
        this.message = 'Could not load pending appointments.'
      }
    },

    async loadJoined() {
      this.section = 'appointments'
      this.joinedMode = true
      try {
        const res = await axios.get(`${API}/appointments/with-doctors`)
        this.joinedAppointments = res.data
        this.message = 'Showing appointments with matching doctor details.'
      } catch (e) {
        this.message = 'Could not load joined records.'
      }
    },

    async saveDoctor() {
      try {
        if (this.editingId) {
          await axios.put(`${API}/doctors/${this.editingId}`, this.doctorForm)
          this.message = 'Doctor updated successfully.'
        } else {
          await axios.post(`${API}/doctors`, this.doctorForm)
          this.message = 'Doctor added successfully.'
        }
        this.resetForm()
        await this.loadAll()
      } catch (e) {
        this.message = 'Could not save doctor. Check required fields and backend.'
      }
    },

    async saveAppointment() {
      try {
        if (this.editingId) {
          await axios.put(`${API}/appointments/${this.editingId}`, this.appointmentForm)
          this.message = 'Appointment updated successfully.'
        } else {
          await axios.post(`${API}/appointments`, this.appointmentForm)
          this.message = 'Appointment added successfully.'
        }
        this.resetForm()
        await this.loadAll()
      } catch (e) {
        this.message = 'Could not save appointment. Check that the selected doctor exists.'
      }
    },

    editDoctor(d) {
      this.section = 'doctors'
      this.joinedMode = false
      this.editingId = d.id
      this.doctorForm = { doctorId: d.doctorId, name: d.name, specialization: d.specialization, availableDays: d.availableDays }
      window.scrollTo({ top: 0, behavior: 'smooth' })
    },

    editAppointment(a) {
      this.section = 'appointments'
      this.joinedMode = false
      this.editingId = a.id
      this.appointmentForm = {
        appointmentId: a.appointmentId,
        patientName: a.patientName,
        doctorId: a.doctorId,
        appointmentDate: a.appointmentDate,
        status: a.status
      }
      window.scrollTo({ top: 0, behavior: 'smooth' })
    },

    async findById() {
      if (!this.findId.trim()) {
        this.message = 'Enter the MongoDB ID first.'
        return
      }
      try {
        const path = this.section === 'doctors' ? 'doctors' : 'appointments'
        const res = await axios.get(`${API}/${path}/${encodeURIComponent(this.findId.trim())}`)
        if (this.section === 'doctors') this.editDoctor(res.data)
        else this.editAppointment(res.data)
        this.message = 'Record found. Edit the fields and click Update.'
      } catch (e) {
        this.message = 'Record not found. Check the MongoDB ID.'
      }
    },

    async deleteRecord(path, id) {
      if (!window.confirm('Delete this record?')) return
      try {
        await axios.delete(`${API}/${path}/${id}`)
        this.message = 'Record deleted successfully.'
        await this.loadAll()
      } catch (e) {
        this.message = 'Could not delete record.'
      }
    },

    resetForm() {
      this.editingId = null
      this.doctorForm = { doctorId: '', name: '', specialization: '', availableDays: '' }
      this.appointmentForm = { appointmentId: '', patientName: '', doctorId: '', appointmentDate: '', status: 'Pending' }
      this.message = ''
    }
  },

  async mounted() {
    await this.loadAll()
  }
}
</script>

<style>
* { box-sizing: border-box; }
body { margin: 0; font-family: Arial, sans-serif; background: #f0f4f8; color: #1f2937; }
.page { max-width: 1200px; margin: 0 auto; padding: 24px; }
h1 { margin-bottom: 4px; }
.intro { color: #64748b; margin-top: 0; margin-bottom: 24px; }
.card { background: white; border-radius: 10px; padding: 20px; margin-bottom: 18px; box-shadow: 0 2px 8px #0000000d; }
h2 { margin-top: 0; font-size: 20px; }
form { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 10px; }
form label { align-self: end; color: #475569; }
input, select { width: 100%; padding: 11px; border: 1px solid #cbd5e1; border-radius: 6px; background: white; font-size: 14px; }
button { border: 0; background: #2563eb; color: white; padding: 10px 14px; margin: 3px; border-radius: 6px; cursor: pointer; }
button:hover { opacity: .9; }
button.active { background: #1e40af; }
button.secondary { background: #64748b; }
button.danger { background: #dc2626; }
.inline { display: flex; gap: 8px; align-items: center; }
.inline input { flex: 1; }
.table-wrap { width: 100%; overflow-x: auto; }
table { width: 100%; border-collapse: collapse; margin-top: 12px; background: white; }
th, td { text-align: left; padding: 10px; border-bottom: 1px solid #e2e8f0; font-size: 14px; }
th { background: #eff6ff; }
.id { max-width: 130px; overflow-wrap: anywhere; font-size: 12px; }
.message { color: #1d4ed8; min-height: 20px; }
.hint { color: #64748b; font-size: 13px; }
@media (max-width: 650px) { .page { padding: 12px; } .card { padding: 14px; } .inline { align-items: stretch; flex-direction: column; } }
</style>
