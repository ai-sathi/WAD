package com.example.lab.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "exams")
public class Exam {
    @Id private String id;
    private String examId;
    private String examName;
    private String subject;
    private Double maximumMarks;
    private Integer duration;

    public Exam() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getExamId() { return examId; }
    public void setExamId(String examId) { this.examId = examId; }
    public String getExamName() { return examName; }
    public void setExamName(String examName) { this.examName = examName; }
    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }
    public Double getMaximumMarks() { return maximumMarks; }
    public void setMaximumMarks(Double maximumMarks) { this.maximumMarks = maximumMarks; }
    public Integer getDuration() { return duration; }
    public void setDuration(Integer duration) { this.duration = duration; }
}