package com.example.lab.service;

import com.example.lab.model.Result;
import com.example.lab.repository.ResultRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final ResultRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(ResultRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<Result> find(String id) { return repository.findById(id); }
    public Result update(String id, Result incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("exams", "examId", "examId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "results", Map.class).getMappedResults();
    }
    public List<Result> all() { return repository.findAll(); }
}
