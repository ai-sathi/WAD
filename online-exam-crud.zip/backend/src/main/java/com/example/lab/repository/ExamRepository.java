package com.example.lab.repository;
import com.example.lab.model.Exam;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ExamRepository extends MongoRepository<Exam, String> {}
