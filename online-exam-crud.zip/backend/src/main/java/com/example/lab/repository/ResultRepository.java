package com.example.lab.repository;
import com.example.lab.model.Result;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ResultRepository extends MongoRepository<Result, String> {}
