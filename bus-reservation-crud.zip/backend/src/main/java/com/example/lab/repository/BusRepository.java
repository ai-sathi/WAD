package com.example.lab.repository;
import com.example.lab.model.Bus;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface BusRepository extends MongoRepository<Bus, String> {}
