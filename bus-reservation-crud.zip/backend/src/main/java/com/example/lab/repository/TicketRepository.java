package com.example.lab.repository;
import com.example.lab.model.Ticket;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface TicketRepository extends MongoRepository<Ticket, String> {}
