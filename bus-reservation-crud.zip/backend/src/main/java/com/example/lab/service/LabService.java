package com.example.lab.service;

import com.example.lab.model.Ticket;
import com.example.lab.repository.TicketRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final TicketRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(TicketRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<Ticket> find(String id) { return repository.findById(id); }
    public Ticket update(String id, Ticket incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("buses", "busId", "busId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "tickets", Map.class).getMappedResults();
    }
    public List<Ticket> all() { return repository.findAll(); }
}
