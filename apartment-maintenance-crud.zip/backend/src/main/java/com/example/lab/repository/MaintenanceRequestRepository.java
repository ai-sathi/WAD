package com.example.lab.repository;
import com.example.lab.model.MaintenanceRequest;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface MaintenanceRequestRepository extends MongoRepository<MaintenanceRequest, String> {}
