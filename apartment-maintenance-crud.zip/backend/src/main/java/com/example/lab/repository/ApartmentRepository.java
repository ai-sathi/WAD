package com.example.lab.repository;
import com.example.lab.model.Apartment;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ApartmentRepository extends MongoRepository<Apartment, String> {}
