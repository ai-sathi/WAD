package com.example.lab.service;

import com.example.lab.model.MaintenanceRequest;
import com.example.lab.repository.MaintenanceRequestRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final MaintenanceRequestRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(MaintenanceRequestRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<MaintenanceRequest> find(String id) { return repository.findById(id); }
    public MaintenanceRequest update(String id, MaintenanceRequest incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("apartments", "apartmentId", "apartmentId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "maintenanceRequests", Map.class).getMappedResults();
    }
    public List<MaintenanceRequest> all() { return repository.findAll(); }
}
