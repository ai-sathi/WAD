package com.example.lab.repository;
import com.example.lab.model.Event;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface EventRepository extends MongoRepository<Event, String> {}
