package com.example.lab.service;

import com.example.lab.model.Registration;
import com.example.lab.repository.RegistrationRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final RegistrationRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(RegistrationRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<Registration> find(String id) { return repository.findById(id); }
    public Registration update(String id, Registration incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("events", "eventId", "eventId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "registrations", Map.class).getMappedResults();
    }
    public List<Registration> all() { return repository.findAll(); }
}
