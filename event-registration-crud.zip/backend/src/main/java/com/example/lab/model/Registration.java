package com.example.lab.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "registrations")
public class Registration {
    @Id private String id;
    private String registrationId;
    private String participantName;
    private String eventId;
    private String ticketsBooked;
    private String paymentStatus;
    private String status;

    public Registration() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getRegistrationId() { return registrationId; }
    public void setRegistrationId(String registrationId) { this.registrationId = registrationId; }
    public String getParticipantName() { return participantName; }
    public void setParticipantName(String participantName) { this.participantName = participantName; }
    public String getEventId() { return eventId; }
    public void setEventId(String eventId) { this.eventId = eventId; }
    public String getTicketsBooked() { return ticketsBooked; }
    public void setTicketsBooked(String ticketsBooked) { this.ticketsBooked = ticketsBooked; }
    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}