package com.example.lab.repository;
import com.example.lab.model.Payment;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface PaymentRepository extends MongoRepository<Payment, String> {}
