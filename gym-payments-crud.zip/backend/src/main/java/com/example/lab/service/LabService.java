package com.example.lab.service;

import com.example.lab.model.Payment;
import com.example.lab.repository.PaymentRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final PaymentRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(PaymentRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<Payment> find(String id) { return repository.findById(id); }
    public Payment update(String id, Payment incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("members", "memberId", "memberId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "payments", Map.class).getMappedResults();
    }
    public List<Payment> all() { return repository.findAll(); }
}
