package com.example.lab.repository;
import com.example.lab.model.Member;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface MemberRepository extends MongoRepository<Member, String> {}
