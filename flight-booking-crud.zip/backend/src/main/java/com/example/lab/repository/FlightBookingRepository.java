package com.example.lab.repository;
import com.example.lab.model.FlightBooking;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface FlightBookingRepository extends MongoRepository<FlightBooking, String> {}
