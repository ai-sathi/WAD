package com.example.lab.repository;
import com.example.lab.model.Flight;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface FlightRepository extends MongoRepository<Flight, String> {}
