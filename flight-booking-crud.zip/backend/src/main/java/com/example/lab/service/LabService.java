package com.example.lab.service;

import com.example.lab.model.FlightBooking;
import com.example.lab.repository.FlightBookingRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final FlightBookingRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(FlightBookingRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<FlightBooking> find(String id) { return repository.findById(id); }
    public FlightBooking update(String id, FlightBooking incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("flights", "flightId", "flightId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "flightBookings", Map.class).getMappedResults();
    }
    public List<FlightBooking> all() { return repository.findAll(); }
}
