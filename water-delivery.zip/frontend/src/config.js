export default {
  "title": "Water Delivery Management",
  "collections": [
    "customers",
    "waterOrders"
  ],
  "fields": {
    "customers": [
      {
        "key": "customerId",
        "label": "Customer ID",
        "type": "text"
      },
      {
        "key": "name",
        "label": "Customer name",
        "type": "text"
      },
      {
        "key": "email",
        "label": "Email",
        "type": "text"
      },
      {
        "key": "phone",
        "label": "Phone",
        "type": "text"
      },
      {
        "key": "city",
        "label": "City",
        "type": "text"
      }
    ],
    "waterOrders": [
      {
        "key": "orderId",
        "label": "Order ID",
        "type": "text"
      },
      {
        "key": "customerId",
        "label": "Customer ID",
        "type": "text"
      },
      {
        "key": "bottles",
        "label": "Number of bottles",
        "type": "number"
      },
      {
        "key": "deliveryDate",
        "label": "Delivery date",
        "type": "date"
      },
      {
        "key": "status",
        "label": "Status",
        "type": "text"
      }
    ]
  },
  "specialTitle": "Pending water orders",
  "specialDescription": "waterOrders with status=Pending",
  "relation": "customerId"
}