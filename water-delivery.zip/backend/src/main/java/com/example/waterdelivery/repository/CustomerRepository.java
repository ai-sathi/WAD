package com.example.waterdelivery.repository;
import com.example.waterdelivery.model.Customer;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface CustomerRepository extends MongoRepository<Customer, String> {}
