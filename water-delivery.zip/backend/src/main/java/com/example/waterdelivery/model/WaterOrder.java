package com.example.waterdelivery.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "waterOrders")
public class WaterOrder {
    @Id private String id;
    private String orderId;
    private String customerId;
    private double bottles;
    private String deliveryDate;
    private String status;
    public WaterOrder() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }
    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }
    public double getBottles() { return bottles; }
    public void setBottles(double bottles) { this.bottles = bottles; }
    public String getDeliveryDate() { return deliveryDate; }
    public void setDeliveryDate(String deliveryDate) { this.deliveryDate = deliveryDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
