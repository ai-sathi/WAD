package com.example.waterdelivery.repository;
import com.example.waterdelivery.model.WaterOrder;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface WaterOrderRepository extends MongoRepository<WaterOrder, String> {}
