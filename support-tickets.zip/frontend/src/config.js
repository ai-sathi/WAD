export default {
  "title": "Customer Support Tickets",
  "collections": [
    "customers",
    "tickets"
  ],
  "fields": {
    "customers": [
      {
        "key": "customerId",
        "label": "Customer ID",
        "type": "text"
      },
      {
        "key": "name",
        "label": "Customer name",
        "type": "text"
      },
      {
        "key": "email",
        "label": "Email",
        "type": "text"
      },
      {
        "key": "phone",
        "label": "Phone",
        "type": "text"
      },
      {
        "key": "city",
        "label": "City",
        "type": "text"
      }
    ],
    "tickets": [
      {
        "key": "ticketId",
        "label": "Ticket ID",
        "type": "text"
      },
      {
        "key": "customerId",
        "label": "Customer ID",
        "type": "text"
      },
      {
        "key": "subject",
        "label": "Subject",
        "type": "text"
      },
      {
        "key": "priority",
        "label": "Priority",
        "type": "text"
      },
      {
        "key": "status",
        "label": "Status",
        "type": "text"
      }
    ]
  },
  "specialTitle": "Open tickets",
  "specialDescription": "tickets with status=Open",
  "relation": "customerId"
}