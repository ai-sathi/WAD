package com.example.supporttickets.repository;
import com.example.supporttickets.model.Customer;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface CustomerRepository extends MongoRepository<Customer, String> {}
