package com.example.supporttickets.repository;
import com.example.supporttickets.model.Ticket;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface TicketRepository extends MongoRepository<Ticket, String> {}
