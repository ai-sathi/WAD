package com.example.salonbooking.repository;
import com.example.salonbooking.model.Appointment;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface AppointmentRepository extends MongoRepository<Appointment, String> {}
