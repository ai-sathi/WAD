package com.example.salonbooking.repository;
import com.example.salonbooking.model.Stylist;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface StylistRepository extends MongoRepository<Stylist, String> {}
