package com.example.salonbooking.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "stylists")
public class Stylist {
    @Id private String id;
    private String stylistId;
    private String name;
    private String specialty;
    private String phone;
    private String available;
    public Stylist() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getStylistId() { return stylistId; }
    public void setStylistId(String stylistId) { this.stylistId = stylistId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getSpecialty() { return specialty; }
    public void setSpecialty(String specialty) { this.specialty = specialty; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getAvailable() { return available; }
    public void setAvailable(String available) { this.available = available; }
}
