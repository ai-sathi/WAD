export default {
  "title": "Salon Booking Management",
  "collections": [
    "stylists",
    "appointments"
  ],
  "fields": {
    "stylists": [
      {
        "key": "stylistId",
        "label": "Stylist ID",
        "type": "text"
      },
      {
        "key": "name",
        "label": "Stylist name",
        "type": "text"
      },
      {
        "key": "specialty",
        "label": "Specialty",
        "type": "text"
      },
      {
        "key": "phone",
        "label": "Phone",
        "type": "text"
      },
      {
        "key": "available",
        "label": "Available (true/false)",
        "type": "text"
      }
    ],
    "appointments": [
      {
        "key": "appointmentId",
        "label": "Appointment ID",
        "type": "text"
      },
      {
        "key": "stylistId",
        "label": "Stylist ID",
        "type": "text"
      },
      {
        "key": "clientName",
        "label": "Client name",
        "type": "text"
      },
      {
        "key": "date",
        "label": "Appointment date",
        "type": "date"
      },
      {
        "key": "status",
        "label": "Status",
        "type": "text"
      }
    ]
  },
  "specialTitle": "Pending appointments",
  "specialDescription": "appointments with status=Pending",
  "relation": "stylistId"
}