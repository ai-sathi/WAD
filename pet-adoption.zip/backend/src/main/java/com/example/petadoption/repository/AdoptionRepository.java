package com.example.petadoption.repository;
import com.example.petadoption.model.Adoption;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface AdoptionRepository extends MongoRepository<Adoption, String> {}
