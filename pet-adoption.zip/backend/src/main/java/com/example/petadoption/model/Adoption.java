package com.example.petadoption.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "adoptions")
public class Adoption {
    @Id private String id;
    private String adoptionId;
    private String adopterName;
    private String petId;
    private String date;
    private String status;
    public Adoption() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getAdoptionId() { return adoptionId; }
    public void setAdoptionId(String adoptionId) { this.adoptionId = adoptionId; }
    public String getAdopterName() { return adopterName; }
    public void setAdopterName(String adopterName) { this.adopterName = adopterName; }
    public String getPetId() { return petId; }
    public void setPetId(String petId) { this.petId = petId; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
