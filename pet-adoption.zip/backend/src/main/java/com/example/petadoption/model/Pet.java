package com.example.petadoption.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "pets")
public class Pet {
    @Id private String id;
    private String petId;
    private String name;
    private String species;
    private double age;
    private String available;
    public Pet() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getPetId() { return petId; }
    public void setPetId(String petId) { this.petId = petId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getSpecies() { return species; }
    public void setSpecies(String species) { this.species = species; }
    public double getAge() { return age; }
    public void setAge(double age) { this.age = age; }
    public String getAvailable() { return available; }
    public void setAvailable(String available) { this.available = available; }
}
