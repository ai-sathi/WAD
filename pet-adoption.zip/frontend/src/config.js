export default {
  "title": "Pet Adoption Management",
  "collections": [
    "pets",
    "adoptions"
  ],
  "fields": {
    "pets": [
      {
        "key": "petId",
        "label": "Pet ID",
        "type": "text"
      },
      {
        "key": "name",
        "label": "Pet name",
        "type": "text"
      },
      {
        "key": "species",
        "label": "Species",
        "type": "text"
      },
      {
        "key": "age",
        "label": "Age",
        "type": "number"
      },
      {
        "key": "available",
        "label": "Available (true/false)",
        "type": "text"
      }
    ],
    "adoptions": [
      {
        "key": "adoptionId",
        "label": "Adoption ID",
        "type": "text"
      },
      {
        "key": "adopterName",
        "label": "Adopter name",
        "type": "text"
      },
      {
        "key": "petId",
        "label": "Pet ID",
        "type": "text"
      },
      {
        "key": "date",
        "label": "Adoption date",
        "type": "date"
      },
      {
        "key": "status",
        "label": "Status",
        "type": "text"
      }
    ]
  },
  "specialTitle": "Available pets",
  "specialDescription": "pets with available=true",
  "relation": "petId"
}