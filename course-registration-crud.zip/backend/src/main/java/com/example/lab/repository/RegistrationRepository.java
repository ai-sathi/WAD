package com.example.lab.repository;
import com.example.lab.model.Registration;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface RegistrationRepository extends MongoRepository<Registration, String> {}
