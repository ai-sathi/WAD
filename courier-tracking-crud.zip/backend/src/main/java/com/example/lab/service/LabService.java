package com.example.lab.service;

import com.example.lab.model.Shipment;
import com.example.lab.repository.ShipmentRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final ShipmentRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(ShipmentRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<Shipment> find(String id) { return repository.findById(id); }
    public Shipment update(String id, Shipment incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("deliveryAgents", "agentId", "agentId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "shipments", Map.class).getMappedResults();
    }
    public List<Shipment> all() { return repository.findAll(); }
}
