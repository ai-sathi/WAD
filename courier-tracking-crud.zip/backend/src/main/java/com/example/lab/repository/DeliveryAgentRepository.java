package com.example.lab.repository;
import com.example.lab.model.DeliveryAgent;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface DeliveryAgentRepository extends MongoRepository<DeliveryAgent, String> {}
