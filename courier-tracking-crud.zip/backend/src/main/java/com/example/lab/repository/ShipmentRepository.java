package com.example.lab.repository;
import com.example.lab.model.Shipment;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ShipmentRepository extends MongoRepository<Shipment, String> {}
