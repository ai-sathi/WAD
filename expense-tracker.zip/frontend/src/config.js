export default {
  "title": "Expense Tracking Management",
  "collections": [
    "categories",
    "expenses"
  ],
  "fields": {
    "categories": [
      {
        "key": "categoryId",
        "label": "Category ID",
        "type": "text"
      },
      {
        "key": "name",
        "label": "Category name",
        "type": "text"
      },
      {
        "key": "monthlyLimit",
        "label": "Monthly limit",
        "type": "number"
      },
      {
        "key": "description",
        "label": "Description",
        "type": "text"
      }
    ],
    "expenses": [
      {
        "key": "expenseId",
        "label": "Expense ID",
        "type": "text"
      },
      {
        "key": "categoryId",
        "label": "Category ID",
        "type": "text"
      },
      {
        "key": "description",
        "label": "Description",
        "type": "text"
      },
      {
        "key": "amount",
        "label": "Amount",
        "type": "number"
      },
      {
        "key": "date",
        "label": "Date",
        "type": "date"
      }
    ]
  },
  "specialTitle": "High-value expenses",
  "specialDescription": "expenses with amount > 1000",
  "relation": "categoryId"
}