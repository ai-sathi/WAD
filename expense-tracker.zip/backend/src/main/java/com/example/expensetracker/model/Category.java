package com.example.expensetracker.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "categories")
public class Category {
    @Id private String id;
    private String categoryId;
    private String name;
    private double monthlyLimit;
    private String description;
    public Category() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getCategoryId() { return categoryId; }
    public void setCategoryId(String categoryId) { this.categoryId = categoryId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public double getMonthlyLimit() { return monthlyLimit; }
    public void setMonthlyLimit(double monthlyLimit) { this.monthlyLimit = monthlyLimit; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
