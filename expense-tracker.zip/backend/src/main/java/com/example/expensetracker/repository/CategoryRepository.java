package com.example.expensetracker.repository;
import com.example.expensetracker.model.Category;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface CategoryRepository extends MongoRepository<Category, String> {}
