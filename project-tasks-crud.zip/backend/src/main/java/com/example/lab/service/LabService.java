package com.example.lab.service;

import com.example.lab.model.Task;
import com.example.lab.repository.TaskRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final TaskRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(TaskRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<Task> find(String id) { return repository.findById(id); }
    public Task update(String id, Task incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("projects", "projectId", "projectId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "tasks", Map.class).getMappedResults();
    }
    public List<Task> all() { return repository.findAll(); }
}
