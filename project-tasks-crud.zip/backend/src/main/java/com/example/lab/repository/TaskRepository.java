package com.example.lab.repository;
import com.example.lab.model.Task;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface TaskRepository extends MongoRepository<Task, String> {}
