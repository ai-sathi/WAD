package com.example.lab.repository;
import com.example.lab.model.Issue;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface IssueRepository extends MongoRepository<Issue, String> {}
