package com.example.lab.service;

import com.example.lab.model.Issue;
import com.example.lab.repository.IssueRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final IssueRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(IssueRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<Issue> find(String id) { return repository.findById(id); }
    public Issue update(String id, Issue incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("books", "bookId", "bookId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "issues", Map.class).getMappedResults();
    }
    public List<Issue> all() { return repository.findAll(); }
}
