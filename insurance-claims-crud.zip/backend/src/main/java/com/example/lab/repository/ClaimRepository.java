package com.example.lab.repository;
import com.example.lab.model.Claim;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ClaimRepository extends MongoRepository<Claim, String> {}
