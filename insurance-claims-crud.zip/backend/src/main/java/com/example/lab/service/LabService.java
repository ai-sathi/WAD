package com.example.lab.service;

import com.example.lab.model.Claim;
import com.example.lab.repository.ClaimRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final ClaimRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(ClaimRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<Claim> find(String id) { return repository.findById(id); }
    public Claim update(String id, Claim incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("policies", "policyId", "policyId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "claims", Map.class).getMappedResults();
    }
    public List<Claim> all() { return repository.findAll(); }
}
