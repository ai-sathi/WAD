package com.example.movierental.repository;
import com.example.movierental.model.Title;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface TitleRepository extends MongoRepository<Title, String> {}
