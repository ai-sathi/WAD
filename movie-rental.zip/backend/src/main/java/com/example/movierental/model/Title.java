package com.example.movierental.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "titles")
public class Title {
    @Id private String id;
    private String titleId;
    private String name;
    private String genre;
    private double copiesAvailable;
    private double dailyRate;
    public Title() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitleId() { return titleId; }
    public void setTitleId(String titleId) { this.titleId = titleId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }
    public double getCopiesAvailable() { return copiesAvailable; }
    public void setCopiesAvailable(double copiesAvailable) { this.copiesAvailable = copiesAvailable; }
    public double getDailyRate() { return dailyRate; }
    public void setDailyRate(double dailyRate) { this.dailyRate = dailyRate; }
}
