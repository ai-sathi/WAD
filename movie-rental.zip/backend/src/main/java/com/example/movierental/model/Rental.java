package com.example.movierental.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "rentals")
public class Rental {
    @Id private String id;
    private String rentalId;
    private String titleId;
    private String customerName;
    private double days;
    private String status;
    public Rental() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getRentalId() { return rentalId; }
    public void setRentalId(String rentalId) { this.rentalId = rentalId; }
    public String getTitleId() { return titleId; }
    public void setTitleId(String titleId) { this.titleId = titleId; }
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
    public double getDays() { return days; }
    public void setDays(double days) { this.days = days; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
