package com.example.movierental.repository;
import com.example.movierental.model.Rental;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface RentalRepository extends MongoRepository<Rental, String> {}
