export default {
  "title": "Movie Rental Management",
  "collections": [
    "titles",
    "rentals"
  ],
  "fields": {
    "titles": [
      {
        "key": "titleId",
        "label": "Title ID",
        "type": "text"
      },
      {
        "key": "name",
        "label": "Movie title",
        "type": "text"
      },
      {
        "key": "genre",
        "label": "Genre",
        "type": "text"
      },
      {
        "key": "copiesAvailable",
        "label": "Copies available",
        "type": "number"
      },
      {
        "key": "dailyRate",
        "label": "Daily rental rate",
        "type": "number"
      }
    ],
    "rentals": [
      {
        "key": "rentalId",
        "label": "Rental ID",
        "type": "text"
      },
      {
        "key": "titleId",
        "label": "Title ID",
        "type": "text"
      },
      {
        "key": "customerName",
        "label": "Customer name",
        "type": "text"
      },
      {
        "key": "days",
        "label": "Days",
        "type": "number"
      },
      {
        "key": "status",
        "label": "Status",
        "type": "text"
      }
    ]
  },
  "specialTitle": "Available titles",
  "specialDescription": "titles with copiesAvailable > 0",
  "relation": "titleId"
}