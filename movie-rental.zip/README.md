# Movie Rental Management

Exam-practice project built with Spring Boot 3.3.5, Java 17, MongoDB, Vue 3 and Axios.

## Run backend
1. Start MongoDB locally.
2. From `backend`, run `mvn spring-boot:run`. API base: `http://localhost:8080/api`.

## Run frontend
1. From `frontend`, run `npm install`.
2. Run `npm run dev` and open the Vite URL.

## Collections
- `titles`: Title records.
- `rentals`: Rental records.

## API patterns
- `GET /api/titles` and `GET /api/rentals` — list records
- `POST /api/{collection}` — create record
- `GET /api/{collection}/{id}` — find by MongoDB document ID
- `PUT /api/{collection}/{id}` — update record
- `DELETE /api/{collection}/{id}` — delete record
- `GET /api/special` — Available titles
- `GET /api/joined` — aggregation `$lookup` joining `rentals` to `titles` using `titleId`
- `GET /api/filter/{collection}?field=status&value=Pending` — text filter

The UI uses ordinary form fields, tables, and Edit/Delete buttons; users do not enter JSON. For the aggregation to match records, seed both collections with the same `titleId` value (for example `X101`) and keep its data type consistent.
