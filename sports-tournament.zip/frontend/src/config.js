export default {
  "title": "Sports Tournament Management",
  "collections": [
    "teams",
    "matches"
  ],
  "fields": {
    "teams": [
      {
        "key": "teamId",
        "label": "Team ID",
        "type": "text"
      },
      {
        "key": "name",
        "label": "Team name",
        "type": "text"
      },
      {
        "key": "coach",
        "label": "Coach",
        "type": "text"
      },
      {
        "key": "points",
        "label": "Points",
        "type": "number"
      },
      {
        "key": "city",
        "label": "City",
        "type": "text"
      }
    ],
    "matches": [
      {
        "key": "matchId",
        "label": "Match ID",
        "type": "text"
      },
      {
        "key": "teamId",
        "label": "Team ID",
        "type": "text"
      },
      {
        "key": "opponent",
        "label": "Opponent",
        "type": "text"
      },
      {
        "key": "date",
        "label": "Match date",
        "type": "date"
      },
      {
        "key": "status",
        "label": "Status",
        "type": "text"
      }
    ]
  },
  "specialTitle": "Scheduled matches",
  "specialDescription": "matches with status=Scheduled",
  "relation": "teamId"
}