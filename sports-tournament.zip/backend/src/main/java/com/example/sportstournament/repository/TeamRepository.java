package com.example.sportstournament.repository;
import com.example.sportstournament.model.Team;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface TeamRepository extends MongoRepository<Team, String> {}
