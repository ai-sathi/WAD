package com.example.sportstournament.repository;
import com.example.sportstournament.model.Match;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface MatchRepository extends MongoRepository<Match, String> {}
