package com.example.sportstournament.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "teams")
public class Team {
    @Id private String id;
    private String teamId;
    private String name;
    private String coach;
    private double points;
    private String city;
    public Team() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTeamId() { return teamId; }
    public void setTeamId(String teamId) { this.teamId = teamId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCoach() { return coach; }
    public void setCoach(String coach) { this.coach = coach; }
    public double getPoints() { return points; }
    public void setPoints(double points) { this.points = points; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
}
