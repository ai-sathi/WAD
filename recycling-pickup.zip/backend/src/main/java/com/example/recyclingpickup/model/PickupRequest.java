package com.example.recyclingpickup.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "pickupRequests")
public class PickupRequest {
    @Id private String id;
    private String requestId;
    private String zoneId;
    private String residentName;
    private String materialType;
    private String status;
    public PickupRequest() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getRequestId() { return requestId; }
    public void setRequestId(String requestId) { this.requestId = requestId; }
    public String getZoneId() { return zoneId; }
    public void setZoneId(String zoneId) { this.zoneId = zoneId; }
    public String getResidentName() { return residentName; }
    public void setResidentName(String residentName) { this.residentName = residentName; }
    public String getMaterialType() { return materialType; }
    public void setMaterialType(String materialType) { this.materialType = materialType; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
