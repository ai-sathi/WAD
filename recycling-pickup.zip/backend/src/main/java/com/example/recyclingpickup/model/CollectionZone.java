package com.example.recyclingpickup.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "collectionZones")
public class CollectionZone {
    @Id private String id;
    private String zoneId;
    private String name;
    private String area;
    private String active;
    private String pickupDay;
    public CollectionZone() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getZoneId() { return zoneId; }
    public void setZoneId(String zoneId) { this.zoneId = zoneId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getArea() { return area; }
    public void setArea(String area) { this.area = area; }
    public String getActive() { return active; }
    public void setActive(String active) { this.active = active; }
    public String getPickupDay() { return pickupDay; }
    public void setPickupDay(String pickupDay) { this.pickupDay = pickupDay; }
}
