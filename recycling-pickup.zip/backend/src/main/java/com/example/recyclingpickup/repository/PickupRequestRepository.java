package com.example.recyclingpickup.repository;
import com.example.recyclingpickup.model.PickupRequest;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface PickupRequestRepository extends MongoRepository<PickupRequest, String> {}
