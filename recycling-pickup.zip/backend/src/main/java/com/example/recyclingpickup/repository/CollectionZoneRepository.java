package com.example.recyclingpickup.repository;
import com.example.recyclingpickup.model.CollectionZone;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface CollectionZoneRepository extends MongoRepository<CollectionZone, String> {}
