export default {
  "title": "Recycling Pickup Management",
  "collections": [
    "collectionZones",
    "pickupRequests"
  ],
  "fields": {
    "collectionZones": [
      {
        "key": "zoneId",
        "label": "Zone ID",
        "type": "text"
      },
      {
        "key": "name",
        "label": "Zone name",
        "type": "text"
      },
      {
        "key": "area",
        "label": "Area",
        "type": "text"
      },
      {
        "key": "active",
        "label": "Active (true/false)",
        "type": "text"
      },
      {
        "key": "pickupDay",
        "label": "Pickup day",
        "type": "text"
      }
    ],
    "pickupRequests": [
      {
        "key": "requestId",
        "label": "Request ID",
        "type": "text"
      },
      {
        "key": "zoneId",
        "label": "Zone ID",
        "type": "text"
      },
      {
        "key": "residentName",
        "label": "Resident name",
        "type": "text"
      },
      {
        "key": "materialType",
        "label": "Material type",
        "type": "text"
      },
      {
        "key": "status",
        "label": "Status",
        "type": "text"
      }
    ]
  },
  "specialTitle": "Scheduled pickups",
  "specialDescription": "pickupRequests with status=Scheduled",
  "relation": "zoneId"
}