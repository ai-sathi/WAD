package com.example.parkingmanagement.repository;
import com.example.parkingmanagement.model.ParkingBooking;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ParkingBookingRepository extends MongoRepository<ParkingBooking, String> {}
