package com.example.parkingmanagement.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "parkingSlots")
public class ParkingSlot {
    @Id private String id;
    private String slotId;
    private String location;
    private String vehicleType;
    private String occupied;
    private double hourlyRate;
    public ParkingSlot() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getSlotId() { return slotId; }
    public void setSlotId(String slotId) { this.slotId = slotId; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getVehicleType() { return vehicleType; }
    public void setVehicleType(String vehicleType) { this.vehicleType = vehicleType; }
    public String getOccupied() { return occupied; }
    public void setOccupied(String occupied) { this.occupied = occupied; }
    public double getHourlyRate() { return hourlyRate; }
    public void setHourlyRate(double hourlyRate) { this.hourlyRate = hourlyRate; }
}
