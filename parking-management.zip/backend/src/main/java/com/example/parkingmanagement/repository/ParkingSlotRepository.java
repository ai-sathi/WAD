package com.example.parkingmanagement.repository;
import com.example.parkingmanagement.model.ParkingSlot;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ParkingSlotRepository extends MongoRepository<ParkingSlot, String> {}
