export default {
  "title": "Parking Management",
  "collections": [
    "parkingSlots",
    "parkingBookings"
  ],
  "fields": {
    "parkingSlots": [
      {
        "key": "slotId",
        "label": "Slot ID",
        "type": "text"
      },
      {
        "key": "location",
        "label": "Location",
        "type": "text"
      },
      {
        "key": "vehicleType",
        "label": "Vehicle type",
        "type": "text"
      },
      {
        "key": "occupied",
        "label": "Occupied (true/false)",
        "type": "text"
      },
      {
        "key": "hourlyRate",
        "label": "Hourly rate",
        "type": "number"
      }
    ],
    "parkingBookings": [
      {
        "key": "bookingId",
        "label": "Booking ID",
        "type": "text"
      },
      {
        "key": "slotId",
        "label": "Slot ID",
        "type": "text"
      },
      {
        "key": "vehicleNumber",
        "label": "Vehicle number",
        "type": "text"
      },
      {
        "key": "startTime",
        "label": "Start time",
        "type": "text"
      },
      {
        "key": "status",
        "label": "Status",
        "type": "text"
      }
    ]
  },
  "specialTitle": "Free parking slots",
  "specialDescription": "parkingSlots with occupied=false",
  "relation": "slotId"
}