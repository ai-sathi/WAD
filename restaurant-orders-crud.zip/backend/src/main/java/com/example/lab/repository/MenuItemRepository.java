package com.example.lab.repository;
import com.example.lab.model.MenuItem;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface MenuItemRepository extends MongoRepository<MenuItem, String> {}
