package com.example.lab.repository;
import com.example.lab.model.FoodOrder;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface FoodOrderRepository extends MongoRepository<FoodOrder, String> {}
