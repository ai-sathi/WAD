package com.example.lab.service;

import com.example.lab.model.FoodOrder;
import com.example.lab.repository.FoodOrderRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final FoodOrderRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(FoodOrderRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<FoodOrder> find(String id) { return repository.findById(id); }
    public FoodOrder update(String id, FoodOrder incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("menuItems", "itemId", "itemId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "foodOrders", Map.class).getMappedResults();
    }
    public List<FoodOrder> all() { return repository.findAll(); }
}
