export default {
  "title": "Electricity Billing Management",
  "collections": [
    "meters",
    "bills"
  ],
  "fields": {
    "meters": [
      {
        "key": "meterId",
        "label": "Meter ID",
        "type": "text"
      },
      {
        "key": "customerName",
        "label": "Customer name",
        "type": "text"
      },
      {
        "key": "address",
        "label": "Address",
        "type": "text"
      },
      {
        "key": "active",
        "label": "Active (true/false)",
        "type": "text"
      },
      {
        "key": "lastReading",
        "label": "Last reading",
        "type": "number"
      }
    ],
    "bills": [
      {
        "key": "billId",
        "label": "Bill ID",
        "type": "text"
      },
      {
        "key": "meterId",
        "label": "Meter ID",
        "type": "text"
      },
      {
        "key": "units",
        "label": "Units consumed",
        "type": "number"
      },
      {
        "key": "amount",
        "label": "Amount",
        "type": "number"
      },
      {
        "key": "status",
        "label": "Status",
        "type": "text"
      }
    ]
  },
  "specialTitle": "Unpaid bills",
  "specialDescription": "bills with status=Unpaid",
  "relation": "meterId"
}