package com.example.electricitybilling.repository;
import com.example.electricitybilling.model.Bill;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface BillRepository extends MongoRepository<Bill, String> {}
