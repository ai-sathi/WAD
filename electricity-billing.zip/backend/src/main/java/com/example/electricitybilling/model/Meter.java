package com.example.electricitybilling.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "meters")
public class Meter {
    @Id private String id;
    private String meterId;
    private String customerName;
    private String address;
    private String active;
    private double lastReading;
    public Meter() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getMeterId() { return meterId; }
    public void setMeterId(String meterId) { this.meterId = meterId; }
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getActive() { return active; }
    public void setActive(String active) { this.active = active; }
    public double getLastReading() { return lastReading; }
    public void setLastReading(double lastReading) { this.lastReading = lastReading; }
}
