package com.example.electricitybilling.repository;
import com.example.electricitybilling.model.Meter;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface MeterRepository extends MongoRepository<Meter, String> {}
