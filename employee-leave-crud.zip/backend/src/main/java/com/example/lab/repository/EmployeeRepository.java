package com.example.lab.repository;
import com.example.lab.model.Employee;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface EmployeeRepository extends MongoRepository<Employee, String> {}
