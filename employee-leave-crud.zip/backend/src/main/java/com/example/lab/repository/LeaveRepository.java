package com.example.lab.repository;
import com.example.lab.model.Leave;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface LeaveRepository extends MongoRepository<Leave, String> {}
