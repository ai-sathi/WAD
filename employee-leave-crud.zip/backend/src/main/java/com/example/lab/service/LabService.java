package com.example.lab.service;

import com.example.lab.model.Leave;
import com.example.lab.repository.LeaveRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final LeaveRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(LeaveRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<Leave> find(String id) { return repository.findById(id); }
    public Leave update(String id, Leave incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("employees", "employeeId", "employeeId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "leaves", Map.class).getMappedResults();
    }
    public List<Leave> all() { return repository.findAll(); }
}
