package com.example.lab.controller;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.bson.Document;
import java.util.*;

@RestController
@RequestMapping("/api/data")
@CrossOrigin(origins = "http://localhost:5173")
public class CollectionCrudController {
    private final MongoTemplate mongoTemplate;
    private static final Set<String> ALLOWED = Set.of("leaves", "employees");
    public CollectionCrudController(MongoTemplate mongoTemplate) { this.mongoTemplate = mongoTemplate; }

    private boolean allowed(String collection) { return ALLOWED.contains(collection); }
    private Query idQuery(String id) {
        Query q = new Query();
        if (ObjectId.isValid(id)) q.addCriteria(new Criteria().orOperator(Criteria.where("_id").is(id), Criteria.where("_id").is(new ObjectId(id))));
        else q.addCriteria(Criteria.where("_id").is(id));
        return q;
    }
    @GetMapping("/{collection}")
    public ResponseEntity<?> list(@PathVariable String collection, @RequestParam(required=false) String field, @RequestParam(required=false) String value) {
        if (!allowed(collection)) return ResponseEntity.badRequest().body(Map.of("error", "Unknown collection"));
        if (field != null && !field.isBlank() && value != null) {
            Query q = new Query(Criteria.where(field).regex(java.util.regex.Pattern.quote(value), "i"));
            return ResponseEntity.ok(mongoTemplate.find(q, Document.class, collection));
        }
        return ResponseEntity.ok(mongoTemplate.findAll(Document.class, collection));
    }
    @GetMapping("/{collection}/{id}")
    public ResponseEntity<?> get(@PathVariable String collection, @PathVariable String id) {
        if (!allowed(collection)) return ResponseEntity.badRequest().body(Map.of("error", "Unknown collection"));
        Document doc = mongoTemplate.findOne(idQuery(id), Document.class, collection);
        return doc == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(doc);
    }
    @PostMapping("/{collection}")
    public ResponseEntity<?> create(@PathVariable String collection, @RequestBody Map<String,Object> body) {
        if (!allowed(collection)) return ResponseEntity.badRequest().body(Map.of("error", "Unknown collection"));
        Document doc = new Document(body); doc.remove("id"); doc.remove("_id");
        Document saved = mongoTemplate.insert(doc, collection);
        return ResponseEntity.ok(saved);
    }
    @PutMapping("/{collection}/{id}")
    public ResponseEntity<?> update(@PathVariable String collection, @PathVariable String id, @RequestBody Map<String,Object> body) {
        if (!allowed(collection)) return ResponseEntity.badRequest().body(Map.of("error", "Unknown collection"));
        Document old = mongoTemplate.findOne(idQuery(id), Document.class, collection);
        if (old == null) return ResponseEntity.notFound().build();
        Object oldId = old.get("_id"); Document replacement = new Document(body); replacement.put("_id", oldId);
        mongoTemplate.remove(idQuery(id), collection); mongoTemplate.insert(replacement, collection);
        return ResponseEntity.ok(replacement);
    }
    @DeleteMapping("/{collection}/{id}")
    public ResponseEntity<?> delete(@PathVariable String collection, @PathVariable String id) {
        if (!allowed(collection)) return ResponseEntity.badRequest().body(Map.of("error", "Unknown collection"));
        Document old = mongoTemplate.findOne(idQuery(id), Document.class, collection);
        if (old == null) return ResponseEntity.notFound().build();
        mongoTemplate.remove(idQuery(id), collection); return ResponseEntity.noContent().build();
    }
}
