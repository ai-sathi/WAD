const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080'

async function request(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
    ...options,
  })

  const text = await response.text()
  let data = null

  if (text) {
    try {
      data = JSON.parse(text)
    } catch {
      data = text
    }
  }

  if (!response.ok) {
    throw new Error(data?.error || data?.message || `Request failed (${response.status})`)
  }

  return data
}

export const api = {
  getRooms: () => request('/rooms'),
  getRoomTypes: () => request('/rooms/types'),
  getBookings: () => request('/bookings'),
  getBookingCounts: () => request('/bookings/count-by-type'),
  addRoom: (room) => request('/rooms', {
    method: 'POST',
    body: JSON.stringify(room),
  }),
  addBooking: (booking) => request('/bookings', {
    method: 'POST',
    body: JSON.stringify(booking),
  }),
}
