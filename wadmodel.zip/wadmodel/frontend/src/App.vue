<script setup>
import { onMounted, ref } from 'vue'
import { api } from './api'
import RoomList from './components/RoomList.vue'
import BookingStats from './components/BookingStats.vue'
import AddRoomForm from './components/AddRoomForm.vue'
import BookingForm from './components/BookingForm.vue'

const rooms = ref([])
const bookings = ref([])
const roomTypes = ref(['STANDARD', 'DELUXE', 'SUITE'])
const counts = ref([])
const loading = ref(false)
const pageError = ref('')
const activeTab = ref('rooms')

async function loadData() {
  loading.value = true
  pageError.value = ''
  try {
    const results = await Promise.all([
      api.getRooms(),
      api.getBookings(),
      api.getRoomTypes(),
      api.getBookingCounts(),
    ])
    rooms.value = results[0] || []
    bookings.value = results[1] || []
    roomTypes.value = results[2] || roomTypes.value
    counts.value = results[3] || []
  } catch (error) {
    pageError.value = `${error.message}. Check that the Spring Boot backend is running on http://localhost:8080.`
  } finally {
    loading.value = false
  }
}

async function addRoom(room) {
  await api.addRoom(room)
  await loadData()
}

async function addBooking(booking) {
  await api.addBooking(booking)
  await loadData()
}

onMounted(loadData)
</script>

<template>
  <main class="app-shell">
    <header class="hero">
      <div class="hero-copy">
        <p class="eyebrow hero-eyebrow">ROOM MANAGEMENT SYSTEM</p>
        <h1>Stay organized.<br /><span>Book with confidence.</span></h1>
        <p class="hero-description">Manage room inventory, create reservations, and track booking activity in one place.</p>
      </div>
      <div class="hero-metric">
        <span>Total rooms records</span>
        <strong>{{ rooms.length }}</strong>
        <span class="metric-divider"></span>
        <span>Total bookings</span>
        <strong>{{ bookings.length }}</strong>
      </div>
    </header>

    <nav class="tabs" aria-label="Dashboard sections">
      <button :class="{ active: activeTab === 'rooms' }" @click="activeTab = 'rooms'">Rooms & analytics</button>
      <button :class="{ active: activeTab === 'manage' }" @click="activeTab = 'manage'">Manage bookings</button>
    </nav>

    <div v-if="pageError" class="error-banner">
      <strong>Backend connection issue</strong>
      <p>{{ pageError }}</p>
      <button class="button button-secondary" @click="loadData">Retry</button>
    </div>

    <template v-if="activeTab === 'rooms'">
      <div class="dashboard-grid">
        <RoomList :rooms="rooms" :loading="loading" />
        <BookingStats :counts="counts" :loading="loading" />
      </div>
      <section class="panel booking-table-panel">
        <div class="section-heading">
          <div>
            <p class="eyebrow">LATEST ACTIVITY</p>
            <h2>All bookings</h2>
          </div>
          <button class="button button-secondary" @click="loadData">Refresh</button>
        </div>
        <div v-if="bookings.length" class="table-wrap">
          <table>
            <thead>
              <tr><th>Customer</th><th>Room type</th><th>Dates</th><th>Rooms</th></tr>
            </thead>
            <tbody>
              <tr v-for="booking in bookings" :key="booking.bookingId">
                <td><strong>{{ booking.customerName }}</strong><span class="table-subtitle">{{ booking.customerEmail }}</span></td>
                <td><span class="type-label">{{ booking.roomType }}</span></td>
                <td>{{ booking.checkInDate }} → {{ booking.checkOutDate }}</td>
                <td>{{ booking.roomsBooked }}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <p v-else class="empty-state">No bookings yet.</p>
      </section>
    </template>

    <template v-else>
      <div class="forms-grid">
        <AddRoomForm :room-types="roomTypes" :on-created="addRoom" />
        <BookingForm :room-types="roomTypes" :on-created="addBooking" />
      </div>
    </template>

    <footer>Room Booking Management <span>·</span> Vue 3 + Spring Boot + MongoDB</footer>
  </main>
</template>
