<script setup>
import { reactive, ref } from 'vue'

const props = defineProps({
  roomTypes: { type: Array, default: () => ['STANDARD', 'DELUXE', 'SUITE'] },
  onCreated: { type: Function, required: true },
})

const form = reactive({
  customerName: '',
  customerEmail: '',
  customerPhone: '',
  roomType: 'STANDARD',
  checkInDate: '',
  checkOutDate: '',
  roomsBooked: 1,
})
const saving = ref(false)
const error = ref('')
const success = ref('')

async function submit() {
  error.value = ''
  success.value = ''

  if (!form.checkInDate || !form.checkOutDate || form.checkInDate >= form.checkOutDate) {
    error.value = 'Check-out must be after check-in.'
    return
  }

  saving.value = true
  try {
    await props.onCreated({
      ...form,
      roomsBooked: Number(form.roomsBooked),
    })
    success.value = 'Booking created successfully.'
    form.customerName = ''
    form.customerEmail = ''
    form.customerPhone = ''
    form.checkInDate = ''
    form.checkOutDate = ''
    form.roomsBooked = 1
  } catch (e) {
    error.value = e.message || 'Could not create booking.'
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <section class="panel">
    <div class="section-heading">
      <div>
        <p class="eyebrow">RESERVATIONS</p>
        <h2>Create a booking</h2>
      </div>
    </div>

    <form class="form-grid" @submit.prevent="submit">
      <label>
        Customer name
        <input v-model.trim="form.customerName" placeholder="Full name" required />
      </label>
      <label>
        Customer email
        <input v-model.trim="form.customerEmail" type="email" placeholder="name@example.com" required />
      </label>
      <label>
        Phone number
        <input v-model.trim="form.customerPhone" type="tel" placeholder="Contact number" />
      </label>
      <label>
        Room type
        <select v-model="form.roomType" required>
          <option v-for="type in roomTypes" :key="type" :value="type">{{ type }}</option>
        </select>
      </label>
      <label>
        Check-in date
        <input v-model="form.checkInDate" type="date" required />
      </label>
      <label>
        Check-out date
        <input v-model="form.checkOutDate" type="date" :min="form.checkInDate || undefined" required />
      </label>
      <label>
        Number of rooms
        <input v-model.number="form.roomsBooked" type="number" min="1" required />
      </label>
      <div class="form-action">
        <button class="button" type="submit" :disabled="saving">
          {{ saving ? 'Booking…' : 'Confirm booking' }}
        </button>
      </div>
    </form>
    <p v-if="error" class="error-message">{{ error }}</p>
    <p v-if="success" class="success-message">{{ success }}</p>
  </section>
</template>
