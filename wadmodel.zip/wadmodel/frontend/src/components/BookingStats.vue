<script setup>
import { computed } from 'vue'

const props = defineProps({
  counts: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
})

const roomTypes = ['STANDARD', 'DELUXE', 'SUITE']

const normalizedCounts = computed(() => {
  const countMap = new Map(
    props.counts.map((item) => [
      item.roomType ?? item._id,
      Number(item.count ?? 0),
    ]),
  )

  return roomTypes.map((roomType) => ({
    roomType,
    count: countMap.get(roomType) ?? 0,
  }))
})

const maxCount = computed(() => Math.max(1, ...normalizedCounts.value.map((item) => item.count)))

const typeClass = (type) => type.toLowerCase()
</script>

<template>
  <section class="panel">
    <div class="section-heading">
      <div>
        <p class="eyebrow">ANALYTICS</p>
        <h2>Bookings by room type</h2>
      </div>
      <span class="count-pill">MongoDB aggregation</span>
    </div>

    <p v-if="loading" class="muted">Loading statistics…</p>
    <div v-else class="stats-list">
      <article v-for="item in normalizedCounts" :key="item.roomType" class="stat-card">
        <div class="stat-card-heading">
          <span class="type-dot" :class="typeClass(item.roomType)"></span>
          <span>{{ item.roomType }}</span>
          <strong>{{ item.count }}</strong>
        </div>
        <div class="bar-track">
          <div
            class="bar-fill"
            :class="typeClass(item.roomType)"
            :style="{ width: `${(item.count / maxCount) * 100}%` }"
          ></div>
        </div>
        <p class="muted small">booking{{ item.count === 1 ? '' : 's' }}</p>
      </article>
    </div>
    <p class="hint">Counts represent booking records, not the total number of rooms reserved.</p>
  </section>
</template>
