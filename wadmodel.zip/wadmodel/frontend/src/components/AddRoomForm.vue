<script setup>
import { reactive, ref } from 'vue'

const props = defineProps({
  roomTypes: { type: Array, default: () => ['STANDARD', 'DELUXE', 'SUITE'] },
  onCreated: { type: Function, required: true },
})

const form = reactive({
  roomType: 'STANDARD',
  checkInDate: '',
  checkOutDate: '',
  availabilityCount: 1,
  availabilityStatus: 'AVAILABLE',
  capacity: 2,
})
const saving = ref(false)
const error = ref('')

async function submit() {
  error.value = ''
  if (!form.checkInDate || !form.checkOutDate || form.checkInDate >= form.checkOutDate) {
    error.value = 'Enter valid dates. Check-out must be after check-in.'
    return
  }

  saving.value = true
  try {
    await props.onCreated({
      ...form,
      availabilityCount: Number(form.availabilityCount),
      capacity: Number(form.capacity),
      availabilityStatus: Number(form.availabilityCount) > 0 ? 'AVAILABLE' : 'NOT_AVAILABLE',
    })
    form.checkInDate = ''
    form.checkOutDate = ''
  } catch (e) {
    error.value = e.message || 'Could not add room.'
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <section class="panel">
    <div class="section-heading">
      <div>
        <p class="eyebrow">INVENTORY MANAGEMENT</p>
        <h2>Add rooms</h2>
      </div>
    </div>

    <form class="form-grid" @submit.prevent="submit">
      <label>
        Room type
        <select v-model="form.roomType" required>
          <option v-for="type in props.roomTypes" :key="type" :value="type">{{ type }}</option>
        </select>
      </label>
      <label>
        Capacity
        <input v-model.number="form.capacity" type="number" min="1" required />
      </label>
      <label>
        Check-in date
        <input v-model="form.checkInDate" type="date" required />
      </label>
      <label>
        Check-out date
        <input v-model="form.checkOutDate" type="date" :min="form.checkInDate || undefined" required />
      </label>
      <label>
        Available rooms
        <input v-model.number="form.availabilityCount" type="number" min="0" required />
      </label>
      <div class="form-action">
        <button class="button" type="submit" :disabled="saving">
          {{ saving ? 'Saving…' : 'Add room' }}
        </button>
      </div>
    </form>
    <p v-if="error" class="error-message">{{ error }}</p>
  </section>
</template>
