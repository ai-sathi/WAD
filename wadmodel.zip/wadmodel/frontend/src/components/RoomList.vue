<script setup>
defineProps({
  rooms: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
})

const typeClass = (type) => {
  const classes = {
    STANDARD: 'standard',
    DELUXE: 'deluxe',
    SUITE: 'suite',
  }
  return classes[type] || 'other'
}
</script>

<template>
  <section class="panel">
    <div class="section-heading">
      <div>
        <p class="eyebrow">INVENTORY</p>
        <h2>Available rooms</h2>
      </div>
      <span class="count-pill">{{ rooms.length }} records</span>
    </div>

    <p v-if="loading" class="muted">Loading rooms…</p>
    <p v-else-if="rooms.length === 0" class="empty-state">No rooms found. Add a room to get started.</p>

    <div v-else class="room-grid">
      <article
        v-for="room in rooms"
        :key="room.roomId"
        class="room-card"
        :class="typeClass(room.roomType)"
      >
        <div class="room-card-top">
          <span class="type-label">{{ room.roomType }}</span>
          <span class="status" :class="room.availabilityCount > 0 ? 'status-available' : 'status-full'">
            {{ room.availabilityCount > 0 ? 'Available' : 'Full' }}
          </span>
        </div>
        <h3>{{ room.roomId || 'Room record' }}</h3>
        <div class="room-stats">
          <div>
            <span class="stat-label">Available</span>
            <strong>{{ room.availabilityCount }}</strong>
          </div>
          <div>
            <span class="stat-label">Capacity</span>
            <strong>{{ room.capacity }} guests</strong>
          </div>
        </div>
        <div class="date-row">
          <span>Check-in</span><strong>{{ room.checkInDate || '—' }}</strong>
        </div>
        <div class="date-row">
          <span>Check-out</span><strong>{{ room.checkOutDate || '—' }}</strong>
        </div>
      </article>
    </div>
  </section>
</template>
