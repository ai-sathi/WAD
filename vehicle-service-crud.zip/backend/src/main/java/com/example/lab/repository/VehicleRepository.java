package com.example.lab.repository;
import com.example.lab.model.Vehicle;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface VehicleRepository extends MongoRepository<Vehicle, String> {}
