package com.example.lab.service;

import com.example.lab.model.ServiceRecord;
import com.example.lab.repository.ServiceRecordRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final ServiceRecordRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(ServiceRecordRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<ServiceRecord> find(String id) { return repository.findById(id); }
    public ServiceRecord update(String id, ServiceRecord incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("vehicles", "vehicleId", "vehicleId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "serviceRecords", Map.class).getMappedResults();
    }
    public List<ServiceRecord> all() { return repository.findAll(); }
}
