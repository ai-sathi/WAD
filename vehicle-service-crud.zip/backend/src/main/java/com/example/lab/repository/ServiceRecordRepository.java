package com.example.lab.repository;
import com.example.lab.model.ServiceRecord;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ServiceRecordRepository extends MongoRepository<ServiceRecord, String> {}
