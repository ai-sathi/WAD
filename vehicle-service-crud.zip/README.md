# Vehicle Service — Full-stack lab practice

## Stack
- Java 17, Spring Boot 3.3.5, Maven
- MongoDB
- Vue 3 + Vite + Axios

## Features
- Full CRUD (Create, Read, Update, Delete) for both collections: `vehicles` and `serviceRecords`.
- Filter/search records using a field and value.
- `$lookup` aggregation endpoint to join the two collections.
- Vue UI to select either collection, list/filter records, create/update/delete, and inspect joined results.
- Existing scenario models and repositories are retained.

## Run
1. Start MongoDB locally (default URI in `backend/src/main/resources/application.properties`).
2. Backend: `cd backend` then `mvn spring-boot:run`.
3. Frontend in another terminal: `cd frontend`, `npm install`, `npm run dev`.
4. Open the Vite URL, normally `http://localhost:5173`.

## Generic CRUD endpoints
- `GET /api/data/{collection}` — list all; optional `?field=status&value=Pending` filter
- `GET /api/data/{collection}/{id}` — get by id
- `POST /api/data/{collection}` — create JSON document
- `PUT /api/data/{collection}/{id}` — replace/update JSON document
- `DELETE /api/data/{collection}/{id}` — delete by id

Allowed collections: `vehicles`, `serviceRecords`.

## Aggregation
The existing scenario endpoint is `/api/serviceRecords/joined`. It uses Spring Data MongoDB aggregation with `$lookup`.

## Exam reminder
Use normal repository methods for simple CRUD. Use `MongoTemplate` / aggregation with `$lookup` when you must combine documents from the two collections. These are practice starter projects; adapt validation and scenario-specific rules to the exact exam prompt.


## User-friendly CRUD screen
The frontend provides field-by-field forms for creating and editing records. The records table provides Edit and Delete actions, and the search controls filter records by a selected field. No JSON editing is required.
