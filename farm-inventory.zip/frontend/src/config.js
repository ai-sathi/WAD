export default {
  "title": "Farm Inventory Management",
  "collections": [
    "supplies",
    "usageRecords"
  ],
  "fields": {
    "supplies": [
      {
        "key": "supplyId",
        "label": "Supply ID",
        "type": "text"
      },
      {
        "key": "name",
        "label": "Supply name",
        "type": "text"
      },
      {
        "key": "category",
        "label": "Category",
        "type": "text"
      },
      {
        "key": "quantity",
        "label": "Quantity",
        "type": "number"
      },
      {
        "key": "unit",
        "label": "Unit",
        "type": "text"
      }
    ],
    "usageRecords": [
      {
        "key": "usageId",
        "label": "Usage ID",
        "type": "text"
      },
      {
        "key": "supplyId",
        "label": "Supply ID",
        "type": "text"
      },
      {
        "key": "quantityUsed",
        "label": "Quantity used",
        "type": "number"
      },
      {
        "key": "usedBy",
        "label": "Used by",
        "type": "text"
      },
      {
        "key": "date",
        "label": "Date",
        "type": "date"
      }
    ]
  },
  "specialTitle": "Low-stock supplies",
  "specialDescription": "supplies with quantity < 10",
  "relation": "supplyId"
}