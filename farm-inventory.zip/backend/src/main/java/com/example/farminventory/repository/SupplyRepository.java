package com.example.farminventory.repository;
import com.example.farminventory.model.Supply;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface SupplyRepository extends MongoRepository<Supply, String> {}
