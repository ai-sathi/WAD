package com.example.farminventory.repository;
import com.example.farminventory.model.UsageRecord;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface UsageRecordRepository extends MongoRepository<UsageRecord, String> {}
