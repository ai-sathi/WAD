package com.example.farminventory.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "usageRecords")
public class UsageRecord {
    @Id private String id;
    private String usageId;
    private String supplyId;
    private double quantityUsed;
    private String usedBy;
    private String date;
    public UsageRecord() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getUsageId() { return usageId; }
    public void setUsageId(String usageId) { this.usageId = usageId; }
    public String getSupplyId() { return supplyId; }
    public void setSupplyId(String supplyId) { this.supplyId = supplyId; }
    public double getQuantityUsed() { return quantityUsed; }
    public void setQuantityUsed(double quantityUsed) { this.quantityUsed = quantityUsed; }
    public String getUsedBy() { return usedBy; }
    public void setUsedBy(String usedBy) { this.usedBy = usedBy; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
}
