package com.example.equipmentrental.repository;
import com.example.equipmentrental.model.Equipment;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface EquipmentRepository extends MongoRepository<Equipment, String> {}
