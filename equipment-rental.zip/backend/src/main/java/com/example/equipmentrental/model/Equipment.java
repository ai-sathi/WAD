package com.example.equipmentrental.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "equipment")
public class Equipment {
    @Id private String id;
    private String equipmentId;
    private String name;
    private String category;
    private double availableUnits;
    private double dailyRate;
    public Equipment() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getEquipmentId() { return equipmentId; }
    public void setEquipmentId(String equipmentId) { this.equipmentId = equipmentId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public double getAvailableUnits() { return availableUnits; }
    public void setAvailableUnits(double availableUnits) { this.availableUnits = availableUnits; }
    public double getDailyRate() { return dailyRate; }
    public void setDailyRate(double dailyRate) { this.dailyRate = dailyRate; }
}
