package com.example.equipmentrental.repository;
import com.example.equipmentrental.model.RentalOrder;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface RentalOrderRepository extends MongoRepository<RentalOrder, String> {}
