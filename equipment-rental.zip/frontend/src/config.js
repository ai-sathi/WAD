export default {
  "title": "Equipment Rental Management",
  "collections": [
    "equipment",
    "rentalOrders"
  ],
  "fields": {
    "equipment": [
      {
        "key": "equipmentId",
        "label": "Equipment ID",
        "type": "text"
      },
      {
        "key": "name",
        "label": "Equipment name",
        "type": "text"
      },
      {
        "key": "category",
        "label": "Category",
        "type": "text"
      },
      {
        "key": "availableUnits",
        "label": "Available units",
        "type": "number"
      },
      {
        "key": "dailyRate",
        "label": "Daily rate",
        "type": "number"
      }
    ],
    "rentalOrders": [
      {
        "key": "orderId",
        "label": "Order ID",
        "type": "text"
      },
      {
        "key": "equipmentId",
        "label": "Equipment ID",
        "type": "text"
      },
      {
        "key": "renterName",
        "label": "Renter name",
        "type": "text"
      },
      {
        "key": "days",
        "label": "Days",
        "type": "number"
      },
      {
        "key": "status",
        "label": "Status",
        "type": "text"
      }
    ]
  },
  "specialTitle": "Available equipment",
  "specialDescription": "equipment with availableUnits > 0",
  "relation": "equipmentId"
}