package com.example.workoutmanagement.repository;
import com.example.workoutmanagement.model.WorkoutSession;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface WorkoutSessionRepository extends MongoRepository<WorkoutSession, String> {}
