package com.example.workoutmanagement.repository;
import com.example.workoutmanagement.model.Plan;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface PlanRepository extends MongoRepository<Plan, String> {}
