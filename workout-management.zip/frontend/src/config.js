export default {
  "title": "Workout Management",
  "collections": [
    "plans",
    "workoutSessions"
  ],
  "fields": {
    "plans": [
      {
        "key": "planId",
        "label": "Plan ID",
        "type": "text"
      },
      {
        "key": "name",
        "label": "Plan name",
        "type": "text"
      },
      {
        "key": "goal",
        "label": "Goal",
        "type": "text"
      },
      {
        "key": "durationMinutes",
        "label": "Duration (minutes)",
        "type": "number"
      },
      {
        "key": "difficulty",
        "label": "Difficulty",
        "type": "text"
      }
    ],
    "workoutSessions": [
      {
        "key": "sessionId",
        "label": "Session ID",
        "type": "text"
      },
      {
        "key": "planId",
        "label": "Plan ID",
        "type": "text"
      },
      {
        "key": "memberName",
        "label": "Member name",
        "type": "text"
      },
      {
        "key": "date",
        "label": "Date",
        "type": "date"
      },
      {
        "key": "durationMinutes",
        "label": "Duration (minutes)",
        "type": "number"
      }
    ]
  },
  "specialTitle": "Long workout sessions",
  "specialDescription": "workoutSessions with durationMinutes >= 60",
  "relation": "planId"
}