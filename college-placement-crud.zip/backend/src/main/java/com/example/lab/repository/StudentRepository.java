package com.example.lab.repository;
import com.example.lab.model.Student;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface StudentRepository extends MongoRepository<Student, String> {}
