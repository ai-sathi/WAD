package com.example.lab.service;

import com.example.lab.model.Placement;
import com.example.lab.repository.PlacementRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final PlacementRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(PlacementRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<Placement> find(String id) { return repository.findById(id); }
    public Placement update(String id, Placement incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("students", "studentId", "studentId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "placements", Map.class).getMappedResults();
    }
    public List<Placement> all() { return repository.findAll(); }
}
