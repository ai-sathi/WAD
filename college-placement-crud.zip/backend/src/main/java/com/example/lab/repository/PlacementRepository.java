package com.example.lab.repository;
import com.example.lab.model.Placement;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface PlacementRepository extends MongoRepository<Placement, String> {}
