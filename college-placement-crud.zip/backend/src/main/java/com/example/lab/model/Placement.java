package com.example.lab.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "placements")
public class Placement {
    @Id private String id;
    private String placementId;
    private String companyName;
    private String studentId;
    private Double packageLPA;
    private String placementStatus;

    public Placement() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getPlacementId() { return placementId; }
    public void setPlacementId(String placementId) { this.placementId = placementId; }
    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }
    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }
    public Double getPackageLPA() { return packageLPA; }
    public void setPackageLPA(Double packageLPA) { this.packageLPA = packageLPA; }
    public String getPlacementStatus() { return placementStatus; }
    public void setPlacementStatus(String placementStatus) { this.placementStatus = placementStatus; }
}