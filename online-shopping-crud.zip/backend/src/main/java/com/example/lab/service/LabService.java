package com.example.lab.service;

import com.example.lab.model.Order;
import com.example.lab.repository.OrderRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final OrderRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(OrderRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<Order> find(String id) { return repository.findById(id); }
    public Order update(String id, Order incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("products", "productId", "productId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "orders", Map.class).getMappedResults();
    }
    public List<Order> all() { return repository.findAll(); }
}
