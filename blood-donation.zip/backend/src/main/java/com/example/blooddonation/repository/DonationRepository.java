package com.example.blooddonation.repository;
import com.example.blooddonation.model.Donation;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface DonationRepository extends MongoRepository<Donation, String> {}
