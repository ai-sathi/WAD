package com.example.blooddonation.repository;
import com.example.blooddonation.model.Donor;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface DonorRepository extends MongoRepository<Donor, String> {}
