export default {
  "title": "Blood Donation Management",
  "collections": [
    "donors",
    "donations"
  ],
  "fields": {
    "donors": [
      {
        "key": "donorId",
        "label": "Donor ID",
        "type": "text"
      },
      {
        "key": "name",
        "label": "Donor name",
        "type": "text"
      },
      {
        "key": "bloodGroup",
        "label": "Blood group",
        "type": "text"
      },
      {
        "key": "phone",
        "label": "Phone",
        "type": "text"
      },
      {
        "key": "active",
        "label": "Active (true/false)",
        "type": "text"
      }
    ],
    "donations": [
      {
        "key": "donationId",
        "label": "Donation ID",
        "type": "text"
      },
      {
        "key": "campaignId",
        "label": "Campaign ID",
        "type": "text"
      },
      {
        "key": "donorName",
        "label": "Donor name",
        "type": "text"
      },
      {
        "key": "amount",
        "label": "Amount",
        "type": "number"
      },
      {
        "key": "date",
        "label": "Date",
        "type": "date"
      }
    ]
  },
  "specialTitle": "Approved donations",
  "specialDescription": "donations with status=Approved",
  "relation": "donorId"
}