package com.example.lab.repository;
import com.example.lab.model.PurchaseOrder;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface PurchaseOrderRepository extends MongoRepository<PurchaseOrder, String> {}
