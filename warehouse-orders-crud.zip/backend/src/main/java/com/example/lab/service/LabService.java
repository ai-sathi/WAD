package com.example.lab.service;

import com.example.lab.model.PurchaseOrder;
import com.example.lab.repository.PurchaseOrderRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LabService {
    private final PurchaseOrderRepository repository;
    private final MongoTemplate mongoTemplate;
    public LabService(PurchaseOrderRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository; this.mongoTemplate = mongoTemplate;
    }
    public Optional<PurchaseOrder> find(String id) { return repository.findById(id); }
    public PurchaseOrder update(String id, PurchaseOrder incoming) {
        incoming.setId(id);
        if (!repository.existsById(id)) return null;
        return repository.save(incoming);
    }
    public List<Map> joined() {
        LookupOperation lookup = Aggregation.lookup("suppliers", "supplierId", "supplierId", "related");
        Aggregation aggregation = Aggregation.newAggregation(lookup, Aggregation.unwind("related", true));
        return mongoTemplate.aggregate(aggregation, "purchaseOrders", Map.class).getMappedResults();
    }
    public List<PurchaseOrder> all() { return repository.findAll(); }
}
