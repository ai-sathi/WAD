package com.example.lab.repository;
import com.example.lab.model.Supplier;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface SupplierRepository extends MongoRepository<Supplier, String> {}
