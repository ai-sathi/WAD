package com.example.artgallery.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "artists")
public class Artist {
    @Id private String id;
    private String artistId;
    private String name;
    private String medium;
    private String country;
    private String active;
    public Artist() {}
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getArtistId() { return artistId; }
    public void setArtistId(String artistId) { this.artistId = artistId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getMedium() { return medium; }
    public void setMedium(String medium) { this.medium = medium; }
    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }
    public String getActive() { return active; }
    public void setActive(String active) { this.active = active; }
}
