package com.example.artgallery.repository;
import com.example.artgallery.model.Artist;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ArtistRepository extends MongoRepository<Artist, String> {}
