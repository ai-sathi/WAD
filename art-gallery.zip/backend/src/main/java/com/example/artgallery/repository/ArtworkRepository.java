package com.example.artgallery.repository;
import com.example.artgallery.model.Artwork;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ArtworkRepository extends MongoRepository<Artwork, String> {}
