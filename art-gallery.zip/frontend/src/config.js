export default {
  "title": "Art Gallery Management",
  "collections": [
    "artists",
    "artworks"
  ],
  "fields": {
    "artists": [
      {
        "key": "artistId",
        "label": "Artist ID",
        "type": "text"
      },
      {
        "key": "name",
        "label": "Artist name",
        "type": "text"
      },
      {
        "key": "medium",
        "label": "Medium",
        "type": "text"
      },
      {
        "key": "country",
        "label": "Country",
        "type": "text"
      },
      {
        "key": "active",
        "label": "Active (true/false)",
        "type": "text"
      }
    ],
    "artworks": [
      {
        "key": "artworkId",
        "label": "Artwork ID",
        "type": "text"
      },
      {
        "key": "artistId",
        "label": "Artist ID",
        "type": "text"
      },
      {
        "key": "title",
        "label": "Artwork title",
        "type": "text"
      },
      {
        "key": "price",
        "label": "Price",
        "type": "number"
      },
      {
        "key": "status",
        "label": "Status",
        "type": "text"
      }
    ]
  },
  "specialTitle": "Available artworks",
  "specialDescription": "artworks with status=Available",
  "relation": "artistId"
}